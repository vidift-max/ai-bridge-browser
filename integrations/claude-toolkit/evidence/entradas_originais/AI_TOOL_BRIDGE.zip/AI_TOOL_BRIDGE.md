# Ponte de Ferramentas de IA

Uma IA externa só pode usar ferramentas quando o provedor disponibiliza uma interface autorizada.

A ponte deve expor a descoberta de capacidades, os requisitos de autenticação, os contratos de invocação de ferramentas, os esquemas, o escopo de permissões e o tratamento de erros/limites de taxa.

Chamadas de ferramentas não documentadas ou não autorizadas devem ser rejeitadas.
