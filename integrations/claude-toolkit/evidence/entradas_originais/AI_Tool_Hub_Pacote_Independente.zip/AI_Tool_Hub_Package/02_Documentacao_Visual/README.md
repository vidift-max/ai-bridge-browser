# 02 — Documentação visual

**Esta pasta não contém screenshots.** Nenhuma imagem foi capturada neste pacote.

Motivo: o ambiente em que o pacote foi gerado não tem ferramenta de captura de tela nem acesso à interface do aplicativo, e não existe navegador gráfico para abrir a demonstração. Imagens "ilustrativas" desenhadas à mão não seriam capturas reais, então não foram incluídas.

## O que existe no lugar

A demonstração `01_Ferramentas_Exportaveis/js/index.html` (e a versão de arquivo único `index_standalone.html`) é a interface a documentar. Para gerar as capturas reais, siga a sequência abaixo em um navegador e salve cada imagem na pasta indicada.

| Pasta sugerida | Tela a capturar | Sequência de uso |
|---|---|---|
| `01_cronometro/` | Seção "Cronômetro regressivo" | 1. Digitar `2m30s`. 2. Tocar em Iniciar (o relógio conta). 3. Pausar. 4. Retomar. 5. Zerar. 6. Digitar `abc` e Iniciar para ver o erro `INVALID_FORMAT`. |
| `02_receita/` | Seção "Escalar receita" | 1. Manter a receita de exemplo. 2. Digitar 6 porções e tocar em Escalar. 3. Converter 1 cup para ml. 4. Converter 1 cup para g para ver `INCOMPATIBLE_UNITS`. |
| `03_quiz/` | Seção "Quiz" | 1. Tocar em Mostrar perguntas. 2. Marcar respostas. 3. Tocar em Corrigir. |
| `04_grafico/` | Seção "Gráfico SVG" | 1. Tocar em Desenhar. 2. Trocar `"bar"` por `"line"` e desenhar de novo. 3. Colocar um valor negativo para ver `NEGATIVE_VALUE`. |
| `05_cartao_link/` | Seção "Cartão de link" | 1. Montar o cartão com a URL de exemplo. 2. Trocar por `javascript:alert(1)` para ver `UNSUPPORTED_SCHEME`. |

Para cada captura, anote ao lado: o que a tela mostra, o que foi digitado e o resultado esperado (veja a seção da ferramenta em `03_APIs_e_Integracoes/API.md`).

## Ferramentas da plataforma Claude

Nenhuma ferramenta interna do Claude foi documentada por imagens, e nenhuma restrição de código foi contornada por captura de tela. A lista do que não é exportável e o motivo estão em `06_Limitacoes_e_Permissoes/LIMITACOES.md`.
