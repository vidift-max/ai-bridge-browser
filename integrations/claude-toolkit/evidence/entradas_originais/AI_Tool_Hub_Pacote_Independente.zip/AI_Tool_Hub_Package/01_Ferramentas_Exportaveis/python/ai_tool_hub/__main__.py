"""Linha de comando: python -m ai_tool_hub <comando> ...  (sem rede, sem arquivos além dos informados)."""
import argparse
import json
import sys

from . import duration_timer, link_card, quiz_engine, recipe_scaler, svg_chart
from .errors import ToolError


def _load(path):
    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as exc:
        raise ToolError("INVALID_JSON", f"Não foi possível ler JSON de {path}: {exc}")


def build_parser():
    p = argparse.ArgumentParser(prog="ai_tool_hub", description="AI Tool Hub — ferramentas locais.")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("parse-duration", help="Converte '1h30m' em segundos")
    s.add_argument("texto")
    s = sub.add_parser("format-duration", help="Formata segundos")
    s.add_argument("segundos", type=float)
    s.add_argument("--estilo", choices=["clock", "words"], default="clock")
    s = sub.add_parser("convert", help="Converte unidades de cozinha")
    s.add_argument("quantidade", type=float)
    s.add_argument("de")
    s.add_argument("para")
    s = sub.add_parser("scale", help="Escala receita (arquivo JSON) para N porções")
    s.add_argument("receita_json")
    s.add_argument("porcoes", type=float)
    s = sub.add_parser("quiz-grade", help="Corrige quiz (JSON) com respostas (JSON)")
    s.add_argument("quiz_json")
    s.add_argument("respostas_json")
    s = sub.add_parser("chart", help="Gera SVG a partir de especificação JSON")
    s.add_argument("spec_json")
    s = sub.add_parser("link-card", help="Valida URL e monta cartão")
    s.add_argument("url")
    s.add_argument("--titulo", default="")
    s.add_argument("--descricao", default="")
    return p


def main(argv=None):
    args = build_parser().parse_args(argv)
    try:
        if args.cmd == "parse-duration":
            out = duration_timer.parse_duration(args.texto)
        elif args.cmd == "format-duration":
            out = duration_timer.format_duration(args.segundos, args.estilo)
        elif args.cmd == "convert":
            out = recipe_scaler.convert(args.quantidade, args.de, args.para)
        elif args.cmd == "scale":
            out = recipe_scaler.scale_recipe(_load(args.receita_json), args.porcoes)
        elif args.cmd == "quiz-grade":
            out = quiz_engine.grade(_load(args.quiz_json), _load(args.respostas_json))
        elif args.cmd == "chart":
            print(svg_chart.render_chart(_load(args.spec_json)))
            return 0
        else:
            out = link_card.build_link_card({"url": args.url, "title": args.titulo, "description": args.descricao})
    except ToolError as exc:
        print(f"{exc.code}: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(out, ensure_ascii=False, indent=2) if isinstance(out, (dict, list)) else out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
