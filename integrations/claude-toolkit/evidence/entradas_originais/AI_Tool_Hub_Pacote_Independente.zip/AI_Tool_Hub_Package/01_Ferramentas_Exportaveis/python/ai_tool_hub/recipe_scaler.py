"""Ferramenta 2 — recipe_scaler: escala receitas e converte unidades (volume US e massa).

Não aplica densidade: não converte volume <-> massa.
"""
from .errors import ToolError, is_number, round_half_up

_UNITS = {
    "ml": ("volume", 1.0),
    "l": ("volume", 1000.0),
    "tsp": ("volume", 4.92892159375),
    "tbsp": ("volume", 14.78676478125),
    "fl_oz": ("volume", 29.5735295625),
    "cup": ("volume", 236.5882365),
    "g": ("mass", 1.0),
    "kg": ("mass", 1000.0),
    "oz": ("mass", 28.349523125),
    "lb": ("mass", 453.59237),
}
_ALIASES = {
    "milliliter": "ml", "liter": "l", "teaspoon": "tsp", "tablespoon": "tbsp", "fl oz": "fl_oz",
    "cups": "cup", "gram": "g", "kilogram": "kg", "ounce": "oz", "pound": "lb",
}


def normalize_unit(unit):
    if not isinstance(unit, str):
        raise ToolError("UNKNOWN_UNIT", "A unidade deve ser texto.")
    u = unit.strip().lower()
    u = _ALIASES.get(u, u)
    if u not in _UNITS:
        raise ToolError("UNKNOWN_UNIT", f'Unidade desconhecida: "{unit}".')
    return u


def _check_amount(amount):
    if not is_number(amount) or amount < 0:
        raise ToolError("INVALID_AMOUNT", "A quantidade deve ser um número finito maior ou igual a zero.")


def convert(amount, from_unit, to_unit):
    _check_amount(amount)
    a = normalize_unit(from_unit)
    b = normalize_unit(to_unit)
    if _UNITS[a][0] != _UNITS[b][0]:
        raise ToolError("INCOMPATIBLE_UNITS",
                        f"Não é possível converter {_UNITS[a][0]} em {_UNITS[b][0]} sem densidade.")
    return round_half_up(amount * _UNITS[a][1] / _UNITS[b][1], 6)


def scale_recipe(recipe, target_servings):
    if not isinstance(recipe, dict):
        raise ToolError("INVALID_RECIPE", "A receita deve ser um objeto.")
    base = recipe.get("base_servings")
    if not is_number(base) or base <= 0:
        raise ToolError("INVALID_RECIPE", "base_servings deve ser um número positivo.")
    ingredients = recipe.get("ingredients")
    if not isinstance(ingredients, list) or len(ingredients) == 0:
        raise ToolError("INVALID_RECIPE", "ingredients deve ser uma lista não vazia.")
    if not is_number(target_servings) or target_servings <= 0:
        raise ToolError("INVALID_SERVINGS", "A quantidade de porções deve ser um número positivo.")
    factor = target_servings / base
    out = []
    for i, ing in enumerate(ingredients):
        name = ing.get("name") if isinstance(ing, dict) else None
        if not isinstance(name, str) or name.strip() == "":
            raise ToolError("INVALID_RECIPE", f"Ingrediente {i} sem nome válido.")
        _check_amount(ing.get("amount"))
        unit = ing.get("unit")
        unit = None if unit is None else normalize_unit(unit)
        out.append({"name": name.strip(), "amount": round_half_up(ing["amount"] * factor, 4), "unit": unit})
    title = recipe.get("title")
    return {
        "title": title if isinstance(title, str) else "",
        "base_servings": target_servings,
        "scale_factor": round_half_up(factor, 6),
        "ingredients": out,
    }


def format_amount(value):
    if not is_number(value):
        raise ToolError("INVALID_AMOUNT", "Valor inválido.")
    s = f"{value:.2f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return "0" if s == "-0" else s
