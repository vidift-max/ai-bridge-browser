"""Ferramenta 4 — svg_chart: gera gráficos de barras/linhas como texto SVG (sem bibliotecas, sem rede).

Todo texto vindo do usuário é escapado. Valores devem ser >= 0.
"""
import math

from .errors import ToolError, clean_text, escape_xml, is_number

PALETTE = ["#1f6f8b", "#e07a1f", "#3a9d5d", "#8e44ad", "#c0392b", "#7f8c8d"]


def _fmt(n):
    s = f"{math.floor(n * 100 + 0.5) / 100:.2f}"
    return s.rstrip("0").rstrip(".")


def nice_max(v):
    if v <= 0:
        return 1
    exp = math.floor(math.log10(v))
    base = 10 ** exp
    f = v / base
    nf = 1 if f <= 1 else 2 if f <= 2 else 5 if f <= 5 else 10
    return nf * base


def _validate(spec):
    if not isinstance(spec, dict):
        raise ToolError("INVALID_SPEC", "A especificação deve ser um objeto.")
    if spec.get("type") not in ("bar", "line"):
        raise ToolError("INVALID_SPEC", 'type deve ser "bar" ou "line".')
    labels = spec.get("labels")
    if not isinstance(labels, list) or not 1 <= len(labels) <= 50:
        raise ToolError("INVALID_SPEC", "labels deve ter entre 1 e 50 itens.")
    for lab in labels:
        if isinstance(lab, bool) or not isinstance(lab, (str, int, float)):
            raise ToolError("INVALID_SPEC", "Cada label deve ser texto ou número.")
    series = spec.get("series")
    if not isinstance(series, list) or not 1 <= len(series) <= len(PALETTE):
        raise ToolError("INVALID_SPEC", f"series deve ter entre 1 e {len(PALETTE)} itens.")
    for i, s in enumerate(series):
        if not isinstance(s, dict) or not isinstance(s.get("values"), list):
            raise ToolError("INVALID_SPEC", f"A série {i + 1} precisa de values (lista).")
        if len(s["values"]) != len(labels):
            raise ToolError("LENGTH_MISMATCH",
                            f"A série {i + 1} tem {len(s['values'])} valores, mas há {len(labels)} labels.")
        for v in s["values"]:
            if not is_number(v):
                raise ToolError("INVALID_VALUE", "Os valores devem ser números finitos.")
            if v < 0:
                raise ToolError("NEGATIVE_VALUE", "Valores negativos não são suportados.")
    w = spec.get("width", 640)
    h = spec.get("height", 360)
    ok = all(isinstance(x, int) and not isinstance(x, bool) for x in (w, h))
    if not ok or not (200 <= w <= 2000 and 150 <= h <= 2000):
        raise ToolError("INVALID_SIZE", "width (200–2000) e height (150–2000) devem ser inteiros.")
    return w, h


def render_chart(spec):
    W, H = _validate(spec)
    title = clean_text(spec["title"])[:120] if isinstance(spec.get("title"), str) else ""
    series = spec["series"]
    labels = spec["labels"]
    multi = len(series) > 1
    ml, mr, mt = 48, 16, (40 if title else 16)
    mb = 40 + (24 if multi else 0)
    pw, ph = W - ml - mr, H - mt - mb
    max_val = max(max(s["values"]) for s in series)
    y_max = nice_max(max_val)
    n = len(labels)
    group = pw / n
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
           f'role="img" font-family="sans-serif" font-size="12">',
           f"<title>{escape_xml(title or 'Gráfico')}</title>",
           f'<rect width="{W}" height="{H}" fill="#ffffff"/>']
    if title:
        out.append(f'<text x="{_fmt(W / 2)}" y="24" text-anchor="middle" font-size="16" '
                   f'font-weight="bold" fill="#222">{escape_xml(title)}</text>')
    for t in range(5):
        val = (y_max / 4) * t
        y = mt + ph - (val / y_max) * ph
        out.append(f'<line x1="{ml}" y1="{_fmt(y)}" x2="{W - mr}" y2="{_fmt(y)}" stroke="#dddddd"/>')
        out.append(f'<text x="{ml - 6}" y="{_fmt(y + 4)}" text-anchor="end" fill="#555">{escape_xml(_fmt(val))}</text>')
    for i, lab in enumerate(labels):
        lab_text = clean_text(lab if isinstance(lab, str) else _fmt(lab) if isinstance(lab, float) else lab)[:20]
        out.append(f'<text x="{_fmt(ml + group * i + group / 2)}" y="{mt + ph + 18}" '
                   f'text-anchor="middle" fill="#333">{escape_xml(lab_text)}</text>')
    ns = len(series)
    if spec["type"] == "bar":
        bw = (group * 0.8) / ns
        for si, s in enumerate(series):
            for i, v in enumerate(s["values"]):
                bh = (v / y_max) * ph
                x = ml + group * i + group * 0.1 + bw * si
                out.append(f'<rect x="{_fmt(x)}" y="{_fmt(mt + ph - bh)}" width="{_fmt(bw)}" '
                           f'height="{_fmt(bh)}" fill="{PALETTE[si]}"/>')
    else:
        for si, s in enumerate(series):
            pts = [(_fmt(ml + group * i + group / 2), _fmt(mt + ph - (v / y_max) * ph))
                   for i, v in enumerate(s["values"])]
            out.append('<polyline points="' + " ".join(f"{x},{y}" for x, y in pts) +
                       f'" fill="none" stroke="{PALETTE[si]}" stroke-width="2"/>')
            for x, y in pts:
                out.append(f'<circle cx="{x}" cy="{y}" r="3" fill="{PALETTE[si]}"/>')
    if multi:
        for si, s in enumerate(series):
            lx = ml + si * 110
            name = s.get("name")
            name = clean_text(name)[:14] if isinstance(name, str) and name.strip() else f"Série {si + 1}"
            out.append(f'<rect x="{lx}" y="{H - 18}" width="10" height="10" fill="{PALETTE[si]}"/>')
            out.append(f'<text x="{lx + 14}" y="{H - 9}" fill="#333">{escape_xml(name)}</text>')
    out.append("</svg>")
    return "\n".join(out)
