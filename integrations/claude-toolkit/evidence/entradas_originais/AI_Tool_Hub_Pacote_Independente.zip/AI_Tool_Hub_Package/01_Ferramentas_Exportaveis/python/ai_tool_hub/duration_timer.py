"""Ferramenta 1 — duration_timer: interpreta/formata durações e controla um cronômetro regressivo.

Não emite som nem notificação; apenas calcula estado e tempo restante.
"""
import re
import time

from .errors import ToolError, is_number

MAX_SECONDS = 7 * 24 * 3600
_UNIT_SECONDS = {"d": 86400, "h": 3600, "m": 60, "s": 1}


def _check_range(total):
    if total < 0 or total > MAX_SECONDS:
        raise ToolError("OUT_OF_RANGE", f"A duração deve estar entre 0 e {MAX_SECONDS} segundos (7 dias).")
    return round(total * 1000) / 1000


def parse_duration(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if not is_number(value) or value < 0:
            raise ToolError("INVALID_FORMAT", "Número de segundos inválido.")
        return _check_range(value)
    if not isinstance(value, str):
        raise ToolError("INVALID_FORMAT", "A duração deve ser texto ou número.")
    text = value.strip().lower()
    if text == "":
        raise ToolError("EMPTY_INPUT", "Informe uma duração.")
    m = re.fullmatch(r"(\d+):([0-5]?\d)(?::([0-5]?\d))?", text)
    if m:
        if m.group(3) is not None:
            total = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + int(m.group(3))
        else:
            total = int(m.group(1)) * 60 + int(m.group(2))
        return _check_range(total)
    if re.fullmatch(r"\d+(\.\d+)?", text):
        return _check_range(float(text))
    seen = set()
    total = 0.0
    consumed = 0
    for tok in re.finditer(r"(\d+(?:\.\d+)?)\s*([dhms])", text):
        if text[consumed:tok.start()].strip() != "":
            raise ToolError("INVALID_FORMAT", f'Formato de duração não reconhecido: "{value}".')
        if tok.group(2) in seen:
            raise ToolError("INVALID_FORMAT", f'Unidade repetida: "{tok.group(2)}".')
        seen.add(tok.group(2))
        total += float(tok.group(1)) * _UNIT_SECONDS[tok.group(2)]
        consumed = tok.end()
    if consumed == 0 or text[consumed:].strip() != "":
        raise ToolError("INVALID_FORMAT", f'Formato de duração não reconhecido: "{value}".')
    return _check_range(total)


def format_duration(seconds, style="clock"):
    if not is_number(seconds) or seconds < 0:
        raise ToolError("INVALID_FORMAT", "Segundos inválidos.")
    s = int(seconds)
    h, rem = divmod(s, 3600)
    minutes, sec = divmod(rem, 60)
    if style == "clock":
        return f"{h:02d}:{minutes:02d}:{sec:02d}"
    if style == "words":
        d, hh = divmod(h, 24)
        parts = []
        if d:
            parts.append(f"{d}d")
        if hh:
            parts.append(f"{hh}h")
        if minutes:
            parts.append(f"{minutes}m")
        if sec or not parts:
            parts.append(f"{sec}s")
        return " ".join(parts)
    raise ToolError("INVALID_FORMAT", f'Estilo desconhecido: "{style}" (use "clock" ou "words").')


class Timer:
    """Máquina de estados: idle -> running <-> paused -> finished. O relógio é injetável (segundos)."""

    def __init__(self, total_seconds, clock=None):
        if not is_number(total_seconds) or total_seconds <= 0:
            raise ToolError("OUT_OF_RANGE", "O cronômetro exige duração maior que zero.")
        _check_range(total_seconds)
        self._total = total_seconds
        self._clock = clock or time.monotonic
        self._remaining = float(total_seconds)
        self._started_at = None
        self._status = "idle"

    def _refresh(self):
        if self._status == "running":
            left = self._remaining - (self._clock() - self._started_at)
            if left <= 0:
                self._remaining = 0.0
                self._started_at = None
                self._status = "finished"

    def _need(self, expected, action):
        self._refresh()
        if self._status not in expected:
            raise ToolError("INVALID_STATE", f'Não é possível "{action}" no estado "{self._status}".')

    def start(self):
        self._need(("idle",), "start")
        self._started_at = self._clock()
        self._status = "running"

    def pause(self):
        self._need(("running",), "pause")
        self._remaining -= self._clock() - self._started_at
        self._started_at = None
        self._status = "paused"

    def resume(self):
        self._need(("paused",), "resume")
        self._started_at = self._clock()
        self._status = "running"

    def reset(self):
        self._remaining = float(self._total)
        self._started_at = None
        self._status = "idle"

    def remaining(self):
        self._refresh()
        if self._status == "running":
            return max(0.0, self._remaining - (self._clock() - self._started_at))
        return self._remaining

    def state(self):
        self._refresh()
        return self._status
