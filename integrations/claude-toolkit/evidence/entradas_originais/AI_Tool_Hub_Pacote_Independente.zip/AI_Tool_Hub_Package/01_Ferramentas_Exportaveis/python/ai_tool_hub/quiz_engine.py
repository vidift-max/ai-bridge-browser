"""Ferramenta 3 — quiz_engine: valida quizzes de múltipla escolha e corrige respostas (local, determinístico).

Não embaralha opções e não gera perguntas (isso exigiria um modelo de IA).
"""
from .errors import ToolError


def _is_str(v):
    return isinstance(v, str) and v.strip() != ""


def validate_quiz(quiz):
    errors = []
    if not isinstance(quiz, dict):
        return {"valid": False, "errors": ["O quiz deve ser um objeto."]}
    if not _is_str(quiz.get("title")):
        errors.append("title deve ser um texto não vazio.")
    questions = quiz.get("questions")
    if not isinstance(questions, list) or len(questions) == 0:
        errors.append("questions deve ser uma lista não vazia.")
        return {"valid": False, "errors": errors}
    q_ids = set()
    for i, q in enumerate(questions):
        tag = f"Pergunta {i + 1}: "
        if not isinstance(q, dict):
            errors.append(tag + "deve ser um objeto.")
            continue
        qid = q.get("id")
        if not _is_str(qid):
            errors.append(tag + "id ausente ou vazio.")
        elif qid in q_ids:
            errors.append(tag + f'id duplicado "{qid}".')
        else:
            q_ids.add(qid)
        if not _is_str(q.get("prompt")):
            errors.append(tag + "prompt ausente ou vazio.")
        options = q.get("options")
        if not isinstance(options, list) or len(options) < 2:
            errors.append(tag + "options deve ter ao menos 2 itens.")
            continue
        o_ids = set()
        for j, o in enumerate(options):
            if not isinstance(o, dict) or not _is_str(o.get("id")) or not _is_str(o.get("text")):
                errors.append(tag + f"opção {j + 1} precisa de id e text não vazios.")
            elif o["id"] in o_ids:
                errors.append(tag + f'id de opção duplicado "{o["id"]}".')
            else:
                o_ids.add(o["id"])
        if not _is_str(q.get("correct_option_id")) or q["correct_option_id"] not in o_ids:
            errors.append(tag + "correct_option_id deve corresponder a uma das opções.")
    return {"valid": len(errors) == 0, "errors": errors}


def grade(quiz, answers):
    check = validate_quiz(quiz)
    if not check["valid"]:
        raise ToolError("INVALID_QUIZ", "Quiz inválido: " + " | ".join(check["errors"]))
    if not isinstance(answers, dict):
        raise ToolError("INVALID_ANSWERS", "answers deve ser um objeto {idDaPergunta: idDaOpção}.")
    known = set()
    correct = 0
    results = []
    for q in quiz["questions"]:
        known.add(q["id"])
        selected = answers.get(q["id"])
        answered = selected is not None
        valid = answered and any(o["id"] == selected for o in q["options"])
        ok = bool(valid and selected == q["correct_option_id"])
        correct += 1 if ok else 0
        explanation = q.get("explanation")
        results.append({
            "id": q["id"],
            "answered": answered,
            "selected": selected,
            "selected_valid": bool(valid),
            "is_correct": ok,
            "correct_option_id": q["correct_option_id"],
            "explanation": explanation if isinstance(explanation, str) else "",
        })
    total = len(quiz["questions"])
    return {
        "title": quiz["title"],
        "total": total,
        "correct": correct,
        "score_percent": int((correct / total) * 1000 + 0.5) / 10,
        "results": results,
        "unknown_answer_ids": [k for k in answers if k not in known],
    }
