"""AI Tool Hub — pacote independente (original). Sem dependências externas."""
from .errors import ToolError, VERSION
from . import duration_timer, recipe_scaler, quiz_engine, svg_chart, link_card

__all__ = ["ToolError", "VERSION", "duration_timer", "recipe_scaler", "quiz_engine", "svg_chart", "link_card"]
