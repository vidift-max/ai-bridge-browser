"""Erros e utilitários comuns do AI Tool Hub (implementação original e independente)."""
import html
import math
import re

VERSION = "0.1.0"


class ToolError(Exception):
    """Erro com código estável (ex.: INVALID_FORMAT) para tratamento programático."""

    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def escape_xml(value):
    return html.escape(str(value), quote=True).replace("&#x27;", "&#39;")


def clean_text(value):
    text = re.sub(r"[\x00-\x1f\x7f]", " ", str(value))
    return re.sub(r"\s+", " ", text).strip()


def is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def round_half_up(value, digits):
    """Mesmo arredondamento de Math.round do JavaScript (para valores >= 0)."""
    p = 10 ** digits
    return math.floor(value * p + 0.5) / p
