"""Ferramenta 5 — link_card: valida URL http(s) e monta cartão de link seguro (HTML escapado).

NÃO acessa a internet: não busca título, imagem ou descrição da página.
"""
import re
from urllib.parse import urlsplit, urlunsplit

from .errors import ToolError, clean_text, escape_xml

_DEFAULT_PORTS = {"http": 80, "https": 443}


def build_link_card(data):
    if not isinstance(data, dict) or not isinstance(data.get("url"), str) or data["url"].strip() == "":
        raise ToolError("EMPTY_INPUT", 'Informe a URL em {"url": "..."}.')
    raw = data["url"].strip()
    if len(raw) > 2048:
        raise ToolError("INVALID_URL", "URL maior que 2048 caracteres.")
    if re.search(r"[\x00-\x20\x7f]", raw):
        raise ToolError("INVALID_URL", "A URL não pode conter espaços ou caracteres de controle.")
    sch = re.match(r"^([a-z][a-z0-9+.\-]*):", raw, re.IGNORECASE)
    if not sch:
        raise ToolError("INVALID_URL", "URL sem esquema (use http:// ou https://).")
    scheme = sch.group(1).lower()
    if scheme not in ("http", "https"):
        raise ToolError("UNSUPPORTED_SCHEME", f'Esquema não permitido: "{scheme}". Apenas http e https.')
    if not re.match(r"^https?://[^/?#]", raw, re.IGNORECASE):
        raise ToolError("INVALID_URL", "URL sem host.")
    try:
        parts = urlsplit(raw)
        port = parts.port
        host = parts.hostname
    except ValueError:
        raise ToolError("INVALID_URL", "URL inválida.")
    if not host:
        raise ToolError("INVALID_URL", "URL sem host.")
    if parts.username or parts.password:
        raise ToolError("CREDENTIALS_IN_URL", "URLs com usuário ou senha embutidos são recusadas.")
    shown_host = f"[{host}]" if ":" in host else host
    netloc = shown_host if port is None or port == _DEFAULT_PORTS[scheme] else f"{shown_host}:{port}"
    url = urlunsplit((scheme, netloc, parts.path or "/", parts.query, parts.fragment))
    title = clean_text(data["title"])[:120] if isinstance(data.get("title"), str) else ""
    desc = clean_text(data["description"])[:300] if isinstance(data.get("description"), str) else ""
    if not title:
        title = shown_host
    html = (f'<a class="link-card" href="{escape_xml(url)}" rel="noopener noreferrer nofollow" target="_blank">'
            f"<strong>{escape_xml(title)}</strong><span>{escape_xml(shown_host)}</span>"
            + (f"<p>{escape_xml(desc)}</p>" if desc else "") + "</a>")
    return {"url": url, "host": shown_host, "title": title, "description": desc, "html": html}
