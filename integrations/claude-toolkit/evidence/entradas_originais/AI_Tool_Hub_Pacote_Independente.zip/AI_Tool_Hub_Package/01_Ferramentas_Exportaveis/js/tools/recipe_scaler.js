/*
 * Ferramenta 2 — recipe_scaler
 * Escala receitas por número de porções e converte unidades (volume US e massa).
 * Não aplica densidade: não converte volume <-> massa.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'));
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.recipeScaler = factory(root.AIToolHub.core);
  }
})(typeof self !== 'undefined' ? self : this, function (core) {
  'use strict';
  var ToolError = core.ToolError;

  // Fator para a unidade-base da categoria (ml para volume, g para massa).
  var UNITS = {
    ml: { kind: 'volume', f: 1 },
    l: { kind: 'volume', f: 1000 },
    tsp: { kind: 'volume', f: 4.92892159375 },
    tbsp: { kind: 'volume', f: 14.78676478125 },
    fl_oz: { kind: 'volume', f: 29.5735295625 },
    cup: { kind: 'volume', f: 236.5882365 },
    g: { kind: 'mass', f: 1 },
    kg: { kind: 'mass', f: 1000 },
    oz: { kind: 'mass', f: 28.349523125 },
    lb: { kind: 'mass', f: 453.59237 }
  };
  var ALIASES = {
    milliliter: 'ml', liter: 'l', teaspoon: 'tsp', tablespoon: 'tbsp', 'fl oz': 'fl_oz', cups: 'cup',
    gram: 'g', kilogram: 'kg', ounce: 'oz', pound: 'lb'
  };

  function normalizeUnit(unit) {
    if (typeof unit !== 'string') {
      throw new ToolError('UNKNOWN_UNIT', 'A unidade deve ser texto.');
    }
    var u = unit.trim().toLowerCase();
    if (Object.prototype.hasOwnProperty.call(ALIASES, u)) u = ALIASES[u];
    if (!Object.prototype.hasOwnProperty.call(UNITS, u)) {
      throw new ToolError('UNKNOWN_UNIT', 'Unidade desconhecida: "' + unit + '".');
    }
    return u;
  }

  function round(value, digits) {
    var p = Math.pow(10, digits);
    return Math.round(value * p) / p;
  }

  function checkAmount(amount) {
    if (typeof amount !== 'number' || !Number.isFinite(amount) || amount < 0) {
      throw new ToolError('INVALID_AMOUNT', 'A quantidade deve ser um número finito maior ou igual a zero.');
    }
  }

  function convert(amount, fromUnit, toUnit) {
    checkAmount(amount);
    var a = normalizeUnit(fromUnit);
    var b = normalizeUnit(toUnit);
    if (UNITS[a].kind !== UNITS[b].kind) {
      throw new ToolError('INCOMPATIBLE_UNITS', 'Não é possível converter ' + UNITS[a].kind + ' em ' + UNITS[b].kind + ' sem densidade.');
    }
    return round(amount * UNITS[a].f / UNITS[b].f, 6);
  }

  function scaleRecipe(recipe, targetServings) {
    if (!core.isPlainObject(recipe)) {
      throw new ToolError('INVALID_RECIPE', 'A receita deve ser um objeto.');
    }
    var base = recipe.base_servings;
    if (typeof base !== 'number' || !Number.isFinite(base) || base <= 0) {
      throw new ToolError('INVALID_RECIPE', 'base_servings deve ser um número positivo.');
    }
    if (!Array.isArray(recipe.ingredients) || recipe.ingredients.length === 0) {
      throw new ToolError('INVALID_RECIPE', 'ingredients deve ser uma lista não vazia.');
    }
    if (typeof targetServings !== 'number' || !Number.isFinite(targetServings) || targetServings <= 0) {
      throw new ToolError('INVALID_SERVINGS', 'A quantidade de porções deve ser um número positivo.');
    }
    var factor = targetServings / base;
    var out = recipe.ingredients.map(function (ing, i) {
      if (!core.isPlainObject(ing) || typeof ing.name !== 'string' || ing.name.trim() === '') {
        throw new ToolError('INVALID_RECIPE', 'Ingrediente ' + i + ' sem nome válido.');
      }
      checkAmount(ing.amount);
      var unit = ing.unit === undefined || ing.unit === null ? null : normalizeUnit(ing.unit);
      return { name: ing.name.trim(), amount: round(ing.amount * factor, 4), unit: unit };
    });
    return {
      title: typeof recipe.title === 'string' ? recipe.title : '',
      base_servings: targetServings,
      scale_factor: round(factor, 6),
      ingredients: out
    };
  }

  function formatAmount(value) {
    if (typeof value !== 'number' || !Number.isFinite(value)) {
      throw new ToolError('INVALID_AMOUNT', 'Valor inválido.');
    }
    var s = value.toFixed(2);
    if (s.indexOf('.') !== -1) s = s.replace(/0+$/, '').replace(/\.$/, '');
    return s === '-0' ? '0' : s;
  }

  return { convert: convert, scaleRecipe: scaleRecipe, formatAmount: formatAmount, normalizeUnit: normalizeUnit };
});
