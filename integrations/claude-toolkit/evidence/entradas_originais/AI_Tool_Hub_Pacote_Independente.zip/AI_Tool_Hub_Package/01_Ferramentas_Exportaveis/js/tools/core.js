/*
 * AI Tool Hub — núcleo comum (JavaScript)
 * Implementação original e independente. Sem rede, sem armazenamento, sem dependências.
 * Funciona no navegador (via <script>) e no Node.js (via require).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.core = factory();
  }
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  class ToolError extends Error {
    constructor(code, message) {
      super(message);
      this.name = 'ToolError';
      this.code = code;
    }
  }

  function escapeXml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  // Remove caracteres de controle (exceto espaço) e normaliza espaços.
  function cleanText(value) {
    return String(value).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v);
  }

  return { ToolError: ToolError, escapeXml: escapeXml, cleanText: cleanText, isPlainObject: isPlainObject, VERSION: '0.1.0' };
});
