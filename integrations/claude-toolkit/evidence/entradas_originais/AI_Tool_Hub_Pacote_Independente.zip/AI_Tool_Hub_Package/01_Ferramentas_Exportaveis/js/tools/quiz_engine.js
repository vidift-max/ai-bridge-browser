/*
 * Ferramenta 3 — quiz_engine
 * Valida um quiz de múltipla escolha (JSON) e corrige respostas. Tudo local e determinístico.
 * Não embaralha opções e não gera perguntas (isso exigiria um modelo de IA).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'));
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.quizEngine = factory(root.AIToolHub.core);
  }
})(typeof self !== 'undefined' ? self : this, function (core) {
  'use strict';
  var ToolError = core.ToolError;
  var has = function (o, k) { return Object.prototype.hasOwnProperty.call(o, k); };
  var isStr = function (v) { return typeof v === 'string' && v.trim() !== ''; };

  function validateQuiz(quiz) {
    var errors = [];
    if (!core.isPlainObject(quiz)) {
      return { valid: false, errors: ['O quiz deve ser um objeto.'] };
    }
    if (!isStr(quiz.title)) errors.push('title deve ser um texto não vazio.');
    if (!Array.isArray(quiz.questions) || quiz.questions.length === 0) {
      errors.push('questions deve ser uma lista não vazia.');
      return { valid: false, errors: errors };
    }
    var qIds = {};
    quiz.questions.forEach(function (q, i) {
      var tag = 'Pergunta ' + (i + 1) + ': ';
      if (!core.isPlainObject(q)) { errors.push(tag + 'deve ser um objeto.'); return; }
      if (!isStr(q.id)) errors.push(tag + 'id ausente ou vazio.');
      else if (has(qIds, q.id)) errors.push(tag + 'id duplicado "' + q.id + '".');
      else qIds[q.id] = true;
      if (!isStr(q.prompt)) errors.push(tag + 'prompt ausente ou vazio.');
      if (!Array.isArray(q.options) || q.options.length < 2) {
        errors.push(tag + 'options deve ter ao menos 2 itens.');
        return;
      }
      var oIds = {};
      q.options.forEach(function (o, j) {
        if (!core.isPlainObject(o) || !isStr(o.id) || !isStr(o.text)) {
          errors.push(tag + 'opção ' + (j + 1) + ' precisa de id e text não vazios.');
        } else if (has(oIds, o.id)) {
          errors.push(tag + 'id de opção duplicado "' + o.id + '".');
        } else {
          oIds[o.id] = true;
        }
      });
      if (!isStr(q.correct_option_id) || !has(oIds, q.correct_option_id)) {
        errors.push(tag + 'correct_option_id deve corresponder a uma das opções.');
      }
    });
    return { valid: errors.length === 0, errors: errors };
  }

  function grade(quiz, answers) {
    var check = validateQuiz(quiz);
    if (!check.valid) {
      throw new ToolError('INVALID_QUIZ', 'Quiz inválido: ' + check.errors.join(' | '));
    }
    if (!core.isPlainObject(answers)) {
      throw new ToolError('INVALID_ANSWERS', 'answers deve ser um objeto {idDaPergunta: idDaOpção}.');
    }
    var known = {};
    var correct = 0;
    var results = quiz.questions.map(function (q) {
      known[q.id] = true;
      var answered = has(answers, q.id) && answers[q.id] !== null && answers[q.id] !== undefined;
      var selected = answered ? answers[q.id] : null;
      var valid = answered && q.options.some(function (o) { return o.id === selected; });
      var ok = valid && selected === q.correct_option_id;
      if (ok) correct += 1;
      return {
        id: q.id,
        answered: answered,
        selected: selected,
        selected_valid: valid,
        is_correct: ok,
        correct_option_id: q.correct_option_id,
        explanation: typeof q.explanation === 'string' ? q.explanation : ''
      };
    });
    var total = quiz.questions.length;
    return {
      title: quiz.title,
      total: total,
      correct: correct,
      score_percent: Math.round((correct / total) * 1000) / 10,
      results: results,
      unknown_answer_ids: Object.keys(answers).filter(function (k) { return !has(known, k); })
    };
  }

  return { validateQuiz: validateQuiz, grade: grade };
});
