/*
 * Ferramenta 5 — link_card
 * Valida uma URL http(s) e monta um cartão de link seguro (HTML escapado).
 * NÃO acessa a internet: não busca título, imagem ou descrição da página.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'));
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.linkCard = factory(root.AIToolHub.core);
  }
})(typeof self !== 'undefined' ? self : this, function (core) {
  'use strict';
  var ToolError = core.ToolError;

  function buildLinkCard(input) {
    if (!core.isPlainObject(input) || typeof input.url !== 'string' || input.url.trim() === '') {
      throw new ToolError('EMPTY_INPUT', 'Informe a URL em { url: "..." }.');
    }
    var raw = input.url.trim();
    if (raw.length > 2048) throw new ToolError('INVALID_URL', 'URL maior que 2048 caracteres.');
    if (/[\u0000-\u0020\u007f]/.test(raw)) throw new ToolError('INVALID_URL', 'A URL não pode conter espaços ou caracteres de controle.');
    var sch = /^([a-z][a-z0-9+.\-]*):/i.exec(raw);
    if (!sch) throw new ToolError('INVALID_URL', 'URL sem esquema (use http:// ou https://).');
    var scheme = sch[1].toLowerCase();
    if (scheme !== 'http' && scheme !== 'https') {
      throw new ToolError('UNSUPPORTED_SCHEME', 'Esquema não permitido: "' + scheme + '". Apenas http e https.');
    }
    if (!/^https?:\/\/[^\/?#]/i.test(raw)) throw new ToolError('INVALID_URL', 'URL sem host.');
    var u;
    try { u = new URL(raw); } catch (e) { throw new ToolError('INVALID_URL', 'URL inválida.'); }
    if (u.username || u.password) {
      throw new ToolError('CREDENTIALS_IN_URL', 'URLs com usuário ou senha embutidos são recusadas.');
    }
    var title = typeof input.title === 'string' ? core.cleanText(input.title).slice(0, 120) : '';
    var desc = typeof input.description === 'string' ? core.cleanText(input.description).slice(0, 300) : '';
    var host = u.hostname;
    if (!title) title = host;
    var esc = core.escapeXml;
    var html = '<a class="link-card" href="' + esc(u.href) + '" rel="noopener noreferrer nofollow" target="_blank">' +
      '<strong>' + esc(title) + '</strong><span>' + esc(host) + '</span>' +
      (desc ? '<p>' + esc(desc) + '</p>' : '') + '</a>';
    return { url: u.href, host: host, title: title, description: desc, html: html };
  }

  return { buildLinkCard: buildLinkCard };
});
