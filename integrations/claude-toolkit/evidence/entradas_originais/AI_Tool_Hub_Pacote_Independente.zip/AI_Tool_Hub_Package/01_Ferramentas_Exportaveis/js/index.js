// Ponto de entrada para uso em Node.js: const hub = require('./index.js');
module.exports = {
  core: require('./tools/core.js'),
  durationTimer: require('./tools/duration_timer.js'),
  recipeScaler: require('./tools/recipe_scaler.js'),
  quizEngine: require('./tools/quiz_engine.js'),
  svgChart: require('./tools/svg_chart.js'),
  linkCard: require('./tools/link_card.js')
};
