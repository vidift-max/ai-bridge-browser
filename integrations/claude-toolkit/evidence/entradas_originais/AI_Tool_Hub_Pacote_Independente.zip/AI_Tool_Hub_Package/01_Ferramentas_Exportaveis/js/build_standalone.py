#!/usr/bin/env python3
"""Gera index_standalone.html e smoke_test_standalone.html: páginas em UM único arquivo (scripts embutidos).

Útil no Android, onde abrir arquivos locais com scripts relativos nem sempre funciona.
Uso: python3 build_standalone.py   (sem dependências)
"""
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["core.js", "duration_timer.js", "recipe_scaler.js", "quiz_engine.js", "svg_chart.js", "link_card.js"]


def read(rel):
    with open(os.path.join(HERE, rel), "r", encoding="utf-8") as fh:
        return fh.read()


def build(origem, destino, extras):
    html = read(origem)
    parts = [read("tools/" + name) for name in ORDER] + [read(e) for e in extras]
    for p in parts:
        if "</script" in p.lower():
            raise SystemExit("Um script contém '</script' e não pode ser embutido com segurança.")
    inline = "<script>\n" + "\n".join(parts) + "\n</script>"
    html, n = re.subn(r'(?:<script src="[^"]+"></script>\s*)+', lambda m: inline + "\n", html, count=1)
    if n != 1 or '<script src=' in html:
        raise SystemExit("Estrutura inesperada em " + origem)
    with open(os.path.join(HERE, destino), "w", encoding="utf-8", newline="\n") as fh:
        fh.write(html)
    print("Gerado " + destino)


def main():
    build("index.html", "index_standalone.html", ["app.js"])
    build("smoke_test.html", "smoke_test_standalone.html", [])


if __name__ == "__main__":
    main()
