/*
 * Ferramenta 1 — duration_timer
 * Interpreta durações ("1h30m", "5:00", "90"), formata e controla um cronômetro regressivo.
 * Não emite som, vibração nem notificação: apenas calcula estado e tempo restante.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'));
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.durationTimer = factory(root.AIToolHub.core);
  }
})(typeof self !== 'undefined' ? self : this, function (core) {
  'use strict';
  var ToolError = core.ToolError;
  var MAX_SECONDS = 7 * 24 * 3600;
  var UNIT_SECONDS = { d: 86400, h: 3600, m: 60, s: 1 };

  function checkRange(total) {
    if (total < 0 || total > MAX_SECONDS) {
      throw new ToolError('OUT_OF_RANGE', 'A duração deve estar entre 0 e ' + MAX_SECONDS + ' segundos (7 dias).');
    }
    return Math.round(total * 1000) / 1000;
  }

  function parseDuration(input) {
    if (typeof input === 'number') {
      if (!Number.isFinite(input) || input < 0) {
        throw new ToolError('INVALID_FORMAT', 'Número de segundos inválido.');
      }
      return checkRange(input);
    }
    if (typeof input !== 'string') {
      throw new ToolError('INVALID_FORMAT', 'A duração deve ser texto ou número.');
    }
    var text = input.trim().toLowerCase();
    if (text === '') {
      throw new ToolError('EMPTY_INPUT', 'Informe uma duração.');
    }
    var m;
    if ((m = /^(\d+):([0-5]?\d)(?::([0-5]?\d))?$/.exec(text))) {
      var total;
      if (m[3] !== undefined) {
        total = Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]);
      } else {
        total = Number(m[1]) * 60 + Number(m[2]);
      }
      return checkRange(total);
    }
    if (/^\d+(\.\d+)?$/.test(text)) {
      return checkRange(Number(text));
    }
    var re = /(\d+(?:\.\d+)?)\s*([dhms])/g;
    var seen = {};
    var sum = 0;
    var consumed = 0;
    var tok;
    while ((tok = re.exec(text)) !== null) {
      var between = text.slice(consumed, tok.index);
      if (between.trim() !== '') {
        throw new ToolError('INVALID_FORMAT', 'Formato de duração não reconhecido: "' + input + '".');
      }
      if (seen[tok[2]]) {
        throw new ToolError('INVALID_FORMAT', 'Unidade repetida: "' + tok[2] + '".');
      }
      seen[tok[2]] = true;
      sum += Number(tok[1]) * UNIT_SECONDS[tok[2]];
      consumed = re.lastIndex;
    }
    if (consumed === 0 || text.slice(consumed).trim() !== '') {
      throw new ToolError('INVALID_FORMAT', 'Formato de duração não reconhecido: "' + input + '".');
    }
    return checkRange(sum);
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function formatDuration(seconds, style) {
    if (typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds < 0) {
      throw new ToolError('INVALID_FORMAT', 'Segundos inválidos.');
    }
    var s = Math.floor(seconds);
    var h = Math.floor(s / 3600);
    var min = Math.floor((s % 3600) / 60);
    var sec = s % 60;
    style = style || 'clock';
    if (style === 'clock') {
      return pad2(h) + ':' + pad2(min) + ':' + pad2(sec);
    }
    if (style === 'words') {
      var d = Math.floor(h / 24);
      var hh = h % 24;
      var parts = [];
      if (d) parts.push(d + 'd');
      if (hh) parts.push(hh + 'h');
      if (min) parts.push(min + 'm');
      if (sec || parts.length === 0) parts.push(sec + 's');
      return parts.join(' ');
    }
    throw new ToolError('INVALID_FORMAT', 'Estilo desconhecido: "' + style + '" (use "clock" ou "words").');
  }

  // Máquina de estados: idle -> running <-> paused -> finished. O relógio é injetável (testes).
  function createTimer(totalSeconds, clock) {
    if (typeof totalSeconds !== 'number' || !Number.isFinite(totalSeconds) || totalSeconds <= 0) {
      throw new ToolError('OUT_OF_RANGE', 'O cronômetro exige duração maior que zero.');
    }
    checkRange(totalSeconds);
    var now = clock || function () { return Date.now(); };
    var remainingMs = totalSeconds * 1000;
    var startedAt = null;
    var status = 'idle';

    function refresh() {
      if (status === 'running') {
        var left = remainingMs - (now() - startedAt);
        if (left <= 0) {
          remainingMs = 0;
          startedAt = null;
          status = 'finished';
        }
      }
    }
    function remaining() {
      refresh();
      if (status === 'running') {
        return Math.max(0, remainingMs - (now() - startedAt)) / 1000;
      }
      return remainingMs / 1000;
    }
    function need(expected, action) {
      refresh();
      if (expected.indexOf(status) === -1) {
        throw new ToolError('INVALID_STATE', 'Não é possível "' + action + '" no estado "' + status + '".');
      }
    }
    return {
      start: function () { need(['idle'], 'start'); startedAt = now(); status = 'running'; },
      pause: function () {
        need(['running'], 'pause');
        remainingMs = remainingMs - (now() - startedAt);
        startedAt = null;
        status = 'paused';
      },
      resume: function () { need(['paused'], 'resume'); startedAt = now(); status = 'running'; },
      reset: function () { remainingMs = totalSeconds * 1000; startedAt = null; status = 'idle'; },
      remaining: remaining,
      state: function () { refresh(); return status; }
    };
  }

  return { parseDuration: parseDuration, formatDuration: formatDuration, createTimer: createTimer, MAX_SECONDS: MAX_SECONDS };
});
