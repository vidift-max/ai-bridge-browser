/*
 * Ferramenta 4 — svg_chart
 * Gera gráficos de barras ou linhas como texto SVG, sem bibliotecas e sem rede.
 * Todo texto vindo do usuário é escapado. Valores devem ser >= 0.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) {
    module.exports = factory(require('./core.js'));
  } else {
    root.AIToolHub = root.AIToolHub || {};
    root.AIToolHub.svgChart = factory(root.AIToolHub.core);
  }
})(typeof self !== 'undefined' ? self : this, function (core) {
  'use strict';
  var ToolError = core.ToolError;
  var PALETTE = ['#1f6f8b', '#e07a1f', '#3a9d5d', '#8e44ad', '#c0392b', '#7f8c8d'];

  function fmt(n) {
    var s = (Math.round(n * 100) / 100).toFixed(2);
    return s.replace(/0+$/, '').replace(/\.$/, '');
  }

  function niceMax(v) {
    if (v <= 0) return 1;
    var exp = Math.floor(Math.log10(v));
    var base = Math.pow(10, exp);
    var f = v / base;
    var nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
    return nf * base;
  }

  function validate(spec) {
    if (!core.isPlainObject(spec)) throw new ToolError('INVALID_SPEC', 'A especificação deve ser um objeto.');
    if (spec.type !== 'bar' && spec.type !== 'line') {
      throw new ToolError('INVALID_SPEC', 'type deve ser "bar" ou "line".');
    }
    if (!Array.isArray(spec.labels) || spec.labels.length === 0 || spec.labels.length > 50) {
      throw new ToolError('INVALID_SPEC', 'labels deve ter entre 1 e 50 itens.');
    }
    spec.labels.forEach(function (l) {
      if (typeof l !== 'string' && typeof l !== 'number') {
        throw new ToolError('INVALID_SPEC', 'Cada label deve ser texto ou número.');
      }
    });
    if (!Array.isArray(spec.series) || spec.series.length === 0 || spec.series.length > PALETTE.length) {
      throw new ToolError('INVALID_SPEC', 'series deve ter entre 1 e ' + PALETTE.length + ' itens.');
    }
    spec.series.forEach(function (s, i) {
      if (!core.isPlainObject(s) || !Array.isArray(s.values)) {
        throw new ToolError('INVALID_SPEC', 'A série ' + (i + 1) + ' precisa de values (lista).');
      }
      if (s.values.length !== spec.labels.length) {
        throw new ToolError('LENGTH_MISMATCH', 'A série ' + (i + 1) + ' tem ' + s.values.length + ' valores, mas há ' + spec.labels.length + ' labels.');
      }
      s.values.forEach(function (v) {
        if (typeof v !== 'number' || !Number.isFinite(v)) {
          throw new ToolError('INVALID_VALUE', 'Os valores devem ser números finitos.');
        }
        if (v < 0) throw new ToolError('NEGATIVE_VALUE', 'Valores negativos não são suportados.');
      });
    });
    var w = spec.width === undefined ? 640 : spec.width;
    var h = spec.height === undefined ? 360 : spec.height;
    if (!Number.isInteger(w) || !Number.isInteger(h) || w < 200 || w > 2000 || h < 150 || h > 2000) {
      throw new ToolError('INVALID_SIZE', 'width (200–2000) e height (150–2000) devem ser inteiros.');
    }
    return { w: w, h: h };
  }

  function renderChart(spec) {
    var size = validate(spec);
    var W = size.w, H = size.h;
    var esc = core.escapeXml;
    var title = typeof spec.title === 'string' ? core.cleanText(spec.title).slice(0, 120) : '';
    var multi = spec.series.length > 1;
    var m = { l: 48, r: 16, t: title ? 40 : 16, b: 40 + (multi ? 24 : 0) };
    var pw = W - m.l - m.r, ph = H - m.t - m.b;
    var maxVal = 0;
    spec.series.forEach(function (s) { s.values.forEach(function (v) { if (v > maxVal) maxVal = v; }); });
    var yMax = niceMax(maxVal);
    var n = spec.labels.length;
    var group = pw / n;
    var out = [];
    out.push('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '" role="img" font-family="sans-serif" font-size="12">');
    out.push('<title>' + esc(title || 'Gráfico') + '</title>');
    out.push('<rect width="' + W + '" height="' + H + '" fill="#ffffff"/>');
    if (title) out.push('<text x="' + fmt(W / 2) + '" y="24" text-anchor="middle" font-size="16" font-weight="bold" fill="#222">' + esc(title) + '</text>');
    for (var t = 0; t <= 4; t++) {
      var val = (yMax / 4) * t;
      var y = m.t + ph - (val / yMax) * ph;
      out.push('<line x1="' + m.l + '" y1="' + fmt(y) + '" x2="' + (W - m.r) + '" y2="' + fmt(y) + '" stroke="#dddddd"/>');
      out.push('<text x="' + (m.l - 6) + '" y="' + fmt(y + 4) + '" text-anchor="end" fill="#555">' + esc(fmt(val)) + '</text>');
    }
    spec.labels.forEach(function (l, i) {
      out.push('<text x="' + fmt(m.l + group * i + group / 2) + '" y="' + (m.t + ph + 18) + '" text-anchor="middle" fill="#333">' + esc(core.cleanText(l).slice(0, 20)) + '</text>');
    });
    var ns = spec.series.length;
    if (spec.type === 'bar') {
      var bw = (group * 0.8) / ns;
      spec.series.forEach(function (s, si) {
        s.values.forEach(function (v, i) {
          var bh = (v / yMax) * ph;
          var x = m.l + group * i + group * 0.1 + bw * si;
          out.push('<rect x="' + fmt(x) + '" y="' + fmt(m.t + ph - bh) + '" width="' + fmt(bw) + '" height="' + fmt(bh) + '" fill="' + PALETTE[si] + '"/>');
        });
      });
    } else {
      spec.series.forEach(function (s, si) {
        var pts = s.values.map(function (v, i) {
          return fmt(m.l + group * i + group / 2) + ',' + fmt(m.t + ph - (v / yMax) * ph);
        });
        out.push('<polyline points="' + pts.join(' ') + '" fill="none" stroke="' + PALETTE[si] + '" stroke-width="2"/>');
        pts.forEach(function (p) {
          var xy = p.split(',');
          out.push('<circle cx="' + xy[0] + '" cy="' + xy[1] + '" r="3" fill="' + PALETTE[si] + '"/>');
        });
      });
    }
    if (multi) {
      spec.series.forEach(function (s, si) {
        var lx = m.l + si * 110;
        var name = typeof s.name === 'string' && s.name.trim() ? core.cleanText(s.name).slice(0, 14) : 'Série ' + (si + 1);
        out.push('<rect x="' + lx + '" y="' + (H - 18) + '" width="10" height="10" fill="' + PALETTE[si] + '"/>');
        out.push('<text x="' + (lx + 14) + '" y="' + (H - 9) + '" fill="#333">' + esc(name) + '</text>');
      });
    }
    out.push('</svg>');
    return out.join('\n');
  }

  return { renderChart: renderChart, niceMax: niceMax };
});
