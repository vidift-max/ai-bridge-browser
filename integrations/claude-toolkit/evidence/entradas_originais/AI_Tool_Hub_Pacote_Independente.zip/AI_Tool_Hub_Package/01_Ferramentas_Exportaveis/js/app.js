/* Demonstração local — só liga a interface às ferramentas. Sem rede, sem armazenamento. */
(function () {
  'use strict';
  var hub = window.AIToolHub;
  var $ = function (id) { return document.getElementById(id); };

  function show(el, text, isError) {
    el.textContent = '';
    var node = document.createElement(isError ? 'div' : 'pre');
    if (isError) node.className = 'err';
    node.textContent = text;
    el.appendChild(node);
  }
  function fail(el, e) {
    show(el, (e && e.code ? e.code + ': ' : 'Erro: ') + (e && e.message ? e.message : String(e)), true);
  }
  function parseJson(text) {
    try { return JSON.parse(text); }
    catch (e) { throw new hub.core.ToolError('INVALID_JSON', 'JSON inválido: ' + e.message); }
  }

  // 1) Cronômetro
  var timer = null, tick = null;
  function paint() {
    if (!timer) return;
    $('clock').textContent = hub.durationTimer.formatDuration(Math.ceil(timer.remaining()));
    var st = timer.state();
    show($('tOut'), 'Estado: ' + st);
    if (st !== 'running' && tick) { clearInterval(tick); tick = null; }
  }
  function timerAction(fn) {
    try { fn(); paint(); } catch (e) { fail($('tOut'), e); }
  }
  $('tStart').onclick = function () {
    timerAction(function () {
      if (tick) { clearInterval(tick); tick = null; }
      timer = hub.durationTimer.createTimer(hub.durationTimer.parseDuration($('dur').value));
      timer.start();
      tick = setInterval(paint, 250);
    });
  };
  $('tPause').onclick = function () { timerAction(function () { timer.pause(); }); };
  $('tResume').onclick = function () {
    timerAction(function () { timer.resume(); if (!tick) tick = setInterval(paint, 250); });
  };
  $('tReset').onclick = function () { timerAction(function () { timer.reset(); }); };

  // 2) Receita
  $('rJson').value = JSON.stringify({
    title: 'Panqueca', base_servings: 4,
    ingredients: [
      { name: 'Farinha', amount: 2, unit: 'cup' },
      { name: 'Ovos', amount: 2, unit: null },
      { name: 'Leite', amount: 500, unit: 'ml' }
    ]
  }, null, 2);
  $('rGo').onclick = function () {
    try {
      var r = hub.recipeScaler.scaleRecipe(parseJson($('rJson').value), Number($('rServ').value));
      var lines = [r.title + ' — ' + r.base_servings + ' porções (fator ' + r.scale_factor + ')'];
      r.ingredients.forEach(function (i) {
        lines.push('• ' + hub.recipeScaler.formatAmount(i.amount) + (i.unit ? ' ' + i.unit : '') + ' ' + i.name);
      });
      show($('rOut'), lines.join('\n'));
    } catch (e) { fail($('rOut'), e); }
  };
  $('cGo').onclick = function () {
    try {
      var v = hub.recipeScaler.convert(Number($('cAmt').value), $('cFrom').value, $('cTo').value);
      show($('rOut'), $('cAmt').value + ' ' + $('cFrom').value + ' = ' + hub.recipeScaler.formatAmount(v) + ' ' + $('cTo').value);
    } catch (e) { fail($('rOut'), e); }
  };

  // 3) Quiz
  $('qJson').value = JSON.stringify({
    title: 'Teste rápido',
    questions: [
      { id: 'q1', prompt: 'Quantos segundos tem 1 minuto?', options: [{ id: 'a', text: '60' }, { id: 'b', text: '100' }], correct_option_id: 'a', explanation: '1 minuto = 60 segundos.' },
      { id: 'q2', prompt: 'Qual unidade mede massa?', options: [{ id: 'a', text: 'ml' }, { id: 'b', text: 'g' }, { id: 'c', text: 'tsp' }], correct_option_id: 'b' }
    ]
  }, null, 2);
  var quiz = null;
  $('qLoad').onclick = function () {
    try {
      quiz = parseJson($('qJson').value);
      var check = hub.quizEngine.validateQuiz(quiz);
      if (!check.valid) { quiz = null; $('qBox').textContent = ''; show($('qOut'), check.errors.join('\n'), true); return; }
      var box = $('qBox');
      box.textContent = '';
      quiz.questions.forEach(function (q) {
        var fs = document.createElement('fieldset');
        fs.className = 'q';
        var lg = document.createElement('legend');
        lg.textContent = q.prompt;
        fs.appendChild(lg);
        q.options.forEach(function (o) {
          var lab = document.createElement('label');
          var inp = document.createElement('input');
          inp.type = 'radio'; inp.name = 'quiz_' + q.id; inp.value = o.id;
          lab.appendChild(inp);
          lab.appendChild(document.createTextNode(o.text));
          fs.appendChild(lab);
        });
        box.appendChild(fs);
      });
      show($('qOut'), 'Responda e toque em Corrigir.');
    } catch (e) { fail($('qOut'), e); }
  };
  $('qGrade').onclick = function () {
    try {
      if (!quiz) throw new hub.core.ToolError('INVALID_STATE', 'Toque em "Mostrar perguntas" primeiro.');
      var answers = {};
      quiz.questions.forEach(function (q) {
        var sel = document.querySelector('input[name="quiz_' + q.id + '"]:checked');
        if (sel) answers[q.id] = sel.value;
      });
      var r = hub.quizEngine.grade(quiz, answers);
      var lines = ['Acertos: ' + r.correct + ' de ' + r.total + ' (' + r.score_percent + '%)'];
      r.results.forEach(function (x) {
        lines.push(x.id + ': ' + (!x.answered ? 'sem resposta' : x.is_correct ? 'correta' : 'errada (certa: ' + x.correct_option_id + ')') + (x.explanation ? ' — ' + x.explanation : ''));
      });
      show($('qOut'), lines.join('\n'));
    } catch (e) { fail($('qOut'), e); }
  };

  // 4) Gráfico
  $('cJson').value = JSON.stringify({
    type: 'bar', title: 'Vendas por mês', labels: ['Jan', 'Fev', 'Mar', 'Abr'],
    series: [{ name: 'Loja A', values: [12, 19, 8, 15] }, { name: 'Loja B', values: [9, 14, 11, 20] }], width: 640, height: 360
  }, null, 2);
  $('cDraw').onclick = function () {
    try {
      // O SVG gerado já tem todo o texto escapado pela ferramenta (ver testes "escapa texto").
      $('cOut').innerHTML = hub.svgChart.renderChart(parseJson($('cJson').value));
    } catch (e) { fail($('cOut'), e); }
  };

  // 5) Cartão de link (montado com DOM/textContent; o HTML gerado fica só como texto de referência)
  $('lGo').onclick = function () {
    try {
      var c = hub.linkCard.buildLinkCard({ url: $('lUrl').value, title: $('lTitle').value, description: $('lDesc').value });
      var out = $('lOut');
      out.textContent = '';
      var a = document.createElement('a');
      a.className = 'link-card'; a.href = c.url; a.target = '_blank'; a.rel = 'noopener noreferrer nofollow';
      var s = document.createElement('strong'); s.textContent = c.title; a.appendChild(s);
      var h = document.createElement('span'); h.textContent = c.host; a.appendChild(h);
      if (c.description) { var p = document.createElement('p'); p.textContent = c.description; a.appendChild(p); }
      out.appendChild(a);
    } catch (e) { fail($('lOut'), e); }
  };
})();
