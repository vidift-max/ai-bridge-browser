// EXEMPLO (não é ferramenta). Uso das 5 ferramentas em Node.js: node 04_Exemplos_de_Uso/exemplo_js.js
const fs = require('fs');
const path = require('path');
const hub = require('../01_Ferramentas_Exportaveis/js/index.js');
const load = (f) => JSON.parse(fs.readFileSync(path.join(__dirname, f), 'utf8'));

const seconds = hub.durationTimer.parseDuration('1h30m');
console.log('1h30m =', seconds, 's ->', hub.durationTimer.formatDuration(seconds, 'words'));

const scaled = hub.recipeScaler.scaleRecipe(load('receita.json'), 6);
console.log('Receita para 6 porções:');
scaled.ingredients.forEach((i) => console.log(' -', hub.recipeScaler.formatAmount(i.amount), i.unit || '', i.name));
console.log('1 cup =', hub.recipeScaler.convert(1, 'cup', 'ml'), 'ml');

const result = hub.quizEngine.grade(load('quiz.json'), load('respostas.json'));
console.log('Quiz:', result.correct + '/' + result.total, '(' + result.score_percent + '%)');

const svg = hub.svgChart.renderChart(load('grafico.json'));
fs.writeFileSync(path.join(__dirname, 'saida_grafico_js.svg'), svg);
console.log('Gráfico salvo em 04_Exemplos_de_Uso/saida_grafico_js.svg (' + svg.length + ' caracteres)');

console.log('Cartão:', hub.linkCard.buildLinkCard({ url: 'https://example.com/a', title: 'Exemplo' }).html);

try { hub.durationTimer.parseDuration('abc'); } catch (e) { console.log('Erro esperado:', e.code); }
