"""EXEMPLO (não é ferramenta). Uso das 5 ferramentas em Python: python3 04_Exemplos_de_Uso/exemplo_python.py"""
import json
import os
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(AQUI, "..", "01_Ferramentas_Exportaveis", "python"))

from ai_tool_hub import ToolError, duration_timer, link_card, quiz_engine, recipe_scaler, svg_chart  # noqa: E402


def carregar(nome):
    with open(os.path.join(AQUI, nome), encoding="utf-8") as fh:
        return json.load(fh)


segundos = duration_timer.parse_duration("1h30m")
print("1h30m =", segundos, "s ->", duration_timer.format_duration(segundos, "words"))

escalada = recipe_scaler.scale_recipe(carregar("receita.json"), 6)
print("Receita para 6 porções:")
for item in escalada["ingredients"]:
    print(" -", recipe_scaler.format_amount(item["amount"]), item["unit"] or "", item["name"])
print("1 cup =", recipe_scaler.convert(1, "cup", "ml"), "ml")

resultado = quiz_engine.grade(carregar("quiz.json"), carregar("respostas.json"))
print(f"Quiz: {resultado['correct']}/{resultado['total']} ({resultado['score_percent']}%)")

svg = svg_chart.render_chart(carregar("grafico.json"))
with open(os.path.join(AQUI, "saida_grafico_py.svg"), "w", encoding="utf-8") as fh:
    fh.write(svg)
print(f"Gráfico salvo em 04_Exemplos_de_Uso/saida_grafico_py.svg ({len(svg)} caracteres)")

print("Cartão:", link_card.build_link_card({"url": "https://example.com/a", "title": "Exemplo"})["html"])

try:
    duration_timer.parse_duration("abc")
except ToolError as exc:
    print("Erro esperado:", exc.code)
