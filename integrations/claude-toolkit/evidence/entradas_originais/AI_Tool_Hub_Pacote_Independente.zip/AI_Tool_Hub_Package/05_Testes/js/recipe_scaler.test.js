const test = require('node:test');
const assert = require('node:assert/strict');
const { recipeScaler: rs } = require('../../01_Ferramentas_Exportaveis/js/index.js');
const code = (c) => (e) => e.name === 'ToolError' && e.code === c;

const recipe = () => ({
  title: 'Panqueca', base_servings: 4,
  ingredients: [
    { name: 'Farinha', amount: 2, unit: 'cup' },
    { name: 'Ovos', amount: 2, unit: null },
    { name: 'Leite', amount: 500, unit: 'ml' }
  ]
});

test('convert: volume e massa', () => {
  assert.equal(rs.convert(1, 'cup', 'ml'), 236.588237);
  assert.equal(rs.convert(1, 'tbsp', 'tsp'), 3);
  assert.equal(rs.convert(1, 'kg', 'g'), 1000);
  assert.equal(rs.convert(1, 'lb', 'oz'), 16);
  assert.equal(rs.convert(1, 'Teaspoon', 'TSP'), 1);
  assert.equal(rs.convert(0, 'g', 'oz'), 0);
});
test('convert: erros', () => {
  assert.throws(() => rs.convert(1, 'cup', 'g'), code('INCOMPATIBLE_UNITS'));
  assert.throws(() => rs.convert(1, 'xyz', 'g'), code('UNKNOWN_UNIT'));
  assert.throws(() => rs.convert(1, 5, 'g'), code('UNKNOWN_UNIT'));
  assert.throws(() => rs.convert(-1, 'g', 'kg'), code('INVALID_AMOUNT'));
  assert.throws(() => rs.convert('1', 'g', 'kg'), code('INVALID_AMOUNT'));
  assert.throws(() => rs.convert(1, '__proto__', 'g'), code('UNKNOWN_UNIT'));
});
test('scaleRecipe: dobra e não altera a entrada', () => {
  const r = recipe();
  const out = rs.scaleRecipe(r, 8);
  assert.equal(out.scale_factor, 2);
  assert.equal(out.base_servings, 8);
  assert.deepEqual(out.ingredients.map((i) => i.amount), [4, 4, 1000]);
  assert.equal(out.ingredients[1].unit, null);
  assert.deepEqual(r, recipe());
});
test('scaleRecipe: fração', () => {
  const out = rs.scaleRecipe(recipe(), 1);
  assert.equal(out.scale_factor, 0.25);
  assert.equal(out.ingredients[0].amount, 0.5);
});
test('scaleRecipe: erros', () => {
  assert.throws(() => rs.scaleRecipe(null, 2), code('INVALID_RECIPE'));
  assert.throws(() => rs.scaleRecipe({ base_servings: 0, ingredients: [{ name: 'a', amount: 1 }] }, 2), code('INVALID_RECIPE'));
  assert.throws(() => rs.scaleRecipe({ base_servings: 2, ingredients: [] }, 2), code('INVALID_RECIPE'));
  assert.throws(() => rs.scaleRecipe(recipe(), 0), code('INVALID_SERVINGS'));
  assert.throws(() => rs.scaleRecipe({ base_servings: 2, ingredients: [{ name: '', amount: 1 }] }, 2), code('INVALID_RECIPE'));
  assert.throws(() => rs.scaleRecipe({ base_servings: 2, ingredients: [{ name: 'x', amount: -1 }] }, 2), code('INVALID_AMOUNT'));
  assert.throws(() => rs.scaleRecipe({ base_servings: 2, ingredients: [{ name: 'x', amount: 1, unit: 'zzz' }] }, 2), code('UNKNOWN_UNIT'));
});
test('formatAmount', () => {
  assert.equal(rs.formatAmount(1.5), '1.5');
  assert.equal(rs.formatAmount(100), '100');
  assert.equal(rs.formatAmount(0), '0');
  assert.equal(rs.formatAmount(0.333333), '0.33');
  assert.throws(() => rs.formatAmount(NaN), code('INVALID_AMOUNT'));
});
