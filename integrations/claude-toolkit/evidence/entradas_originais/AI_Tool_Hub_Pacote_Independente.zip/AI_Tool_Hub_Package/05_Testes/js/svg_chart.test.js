const test = require('node:test');
const assert = require('node:assert/strict');
const { svgChart: sc } = require('../../01_Ferramentas_Exportaveis/js/index.js');
const code = (c) => (e) => e.name === 'ToolError' && e.code === c;
const count = (s, re) => (s.match(re) || []).length;

test('niceMax', () => {
  assert.equal(sc.niceMax(0), 1);
  assert.equal(sc.niceMax(7), 10);
  assert.equal(sc.niceMax(120), 200);
  assert.equal(sc.niceMax(0.3), 0.5);
  assert.equal(sc.niceMax(50), 50);
});
test('barras: estrutura do SVG', () => {
  const svg = sc.renderChart({ type: 'bar', title: 'Vendas', labels: ['Jan', 'Fev', 'Mar'], series: [{ name: 'A', values: [10, 20, 30] }] });
  assert.match(svg, /^<svg xmlns="http:\/\/www\.w3\.org\/2000\/svg"/);
  assert.match(svg, /<\/svg>$/);
  assert.equal(count(svg, /<rect x=/g), 3);
  assert.match(svg, /<title>Vendas<\/title>/);
  assert.equal(count(svg, /<line /g), 5);
});
test('linhas com duas séries e legenda', () => {
  const svg = sc.renderChart({ type: 'line', labels: ['a', 'b'], series: [{ name: 'X', values: [1, 2] }, { name: 'Y', values: [2, 1] }] });
  assert.equal(count(svg, /<polyline /g), 2);
  assert.equal(count(svg, /<circle /g), 4);
  assert.match(svg, />X<\/text>/);
});
test('escapa texto (anti-injeção)', () => {
  const svg = sc.renderChart({ type: 'bar', title: '<script>alert(1)</script>', labels: ['<b>'], series: [{ values: [1] }] });
  assert.ok(!svg.includes('<script>'));
  assert.ok(!svg.includes('<b>'));
  assert.match(svg, /&lt;script&gt;/);
});
test('todos os valores zero não quebra', () => {
  const svg = sc.renderChart({ type: 'bar', labels: ['a'], series: [{ values: [0] }] });
  assert.match(svg, /<svg/);
  assert.ok(!svg.includes('NaN'));
});
test('erros de validação', () => {
  const ok = { type: 'bar', labels: ['a', 'b'], series: [{ values: [1, 2] }] };
  assert.throws(() => sc.renderChart(null), code('INVALID_SPEC'));
  assert.throws(() => sc.renderChart({ ...ok, type: 'pie' }), code('INVALID_SPEC'));
  assert.throws(() => sc.renderChart({ ...ok, labels: [] }), code('INVALID_SPEC'));
  assert.throws(() => sc.renderChart({ ...ok, series: [] }), code('INVALID_SPEC'));
  assert.throws(() => sc.renderChart({ ...ok, series: [{ values: [1] }] }), code('LENGTH_MISMATCH'));
  assert.throws(() => sc.renderChart({ ...ok, series: [{ values: [1, -2] }] }), code('NEGATIVE_VALUE'));
  assert.throws(() => sc.renderChart({ ...ok, series: [{ values: [1, 'x'] }] }), code('INVALID_VALUE'));
  assert.throws(() => sc.renderChart({ ...ok, width: 50 }), code('INVALID_SIZE'));
  assert.throws(() => sc.renderChart({ ...ok, series: Array(7).fill({ values: [1, 2] }) }), code('INVALID_SPEC'));
});
