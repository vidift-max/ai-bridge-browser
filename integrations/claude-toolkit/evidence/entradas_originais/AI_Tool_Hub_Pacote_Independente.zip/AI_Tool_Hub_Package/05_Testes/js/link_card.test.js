const test = require('node:test');
const assert = require('node:assert/strict');
const { linkCard: lc } = require('../../01_Ferramentas_Exportaveis/js/index.js');
const code = (c) => (e) => e.name === 'ToolError' && e.code === c;

test('normaliza URL válida', () => {
  const r = lc.buildLinkCard({ url: 'HTTPS://Example.COM/a?b=1#c' });
  assert.equal(r.url, 'https://example.com/a?b=1#c');
  assert.equal(r.host, 'example.com');
  assert.equal(r.title, 'example.com');
  assert.equal(lc.buildLinkCard({ url: 'https://example.com' }).url, 'https://example.com/');
  assert.equal(lc.buildLinkCard({ url: 'https://example.com:443/x' }).url, 'https://example.com/x');
  assert.equal(lc.buildLinkCard({ url: 'http://example.com:8080/x' }).url, 'http://example.com:8080/x');
});
test('monta HTML escapado com rel seguro', () => {
  const r = lc.buildLinkCard({ url: 'https://example.com', title: '<img src=x onerror=alert(1)>', description: 'a & b "c"' });
  assert.ok(!r.html.includes('<img'));
  assert.match(r.html, /rel="noopener noreferrer nofollow"/);
  assert.match(r.html, /a &amp; b &quot;c&quot;/);
});
test('recusa esquemas perigosos', () => {
  assert.throws(() => lc.buildLinkCard({ url: 'javascript:alert(1)' }), code('UNSUPPORTED_SCHEME'));
  assert.throws(() => lc.buildLinkCard({ url: 'data:text/html,<b>x</b>' }), code('UNSUPPORTED_SCHEME'));
  assert.throws(() => lc.buildLinkCard({ url: 'file:///etc/passwd' }), code('UNSUPPORTED_SCHEME'));
  assert.throws(() => lc.buildLinkCard({ url: 'JaVaScRiPt:alert(1)' }), code('UNSUPPORTED_SCHEME'));
});
test('outros erros', () => {
  assert.throws(() => lc.buildLinkCard(null), code('EMPTY_INPUT'));
  assert.throws(() => lc.buildLinkCard({ url: '  ' }), code('EMPTY_INPUT'));
  assert.throws(() => lc.buildLinkCard({ url: 'example.com' }), code('INVALID_URL'));
  assert.throws(() => lc.buildLinkCard({ url: 'https://exa mple.com' }), code('INVALID_URL'));
  assert.throws(() => lc.buildLinkCard({ url: 'https:///x' }), code('INVALID_URL'));
  assert.throws(() => lc.buildLinkCard({ url: 'https://user:pw@example.com/' }), code('CREDENTIALS_IN_URL'));
  assert.throws(() => lc.buildLinkCard({ url: 'https://example.com/' + 'a'.repeat(2100) }), code('INVALID_URL'));
});
test('host IPv6 mantém colchetes (regressão de paridade)', () => {
  const r = lc.buildLinkCard({ url: 'http://[::1]:8080/x' });
  assert.equal(r.host, '[::1]');
  assert.equal(r.url, 'http://[::1]:8080/x');
});
