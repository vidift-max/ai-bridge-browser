const test = require('node:test');
const assert = require('node:assert/strict');
const { durationTimer: dt } = require('../../01_Ferramentas_Exportaveis/js/index.js');

const code = (c) => (e) => e.name === 'ToolError' && e.code === c;

test('parseDuration: formatos válidos', () => {
  assert.equal(dt.parseDuration('90'), 90);
  assert.equal(dt.parseDuration('5m'), 300);
  assert.equal(dt.parseDuration('1h30m'), 5400);
  assert.equal(dt.parseDuration('2m 30s'), 150);
  assert.equal(dt.parseDuration('1:30'), 90);
  assert.equal(dt.parseDuration('1:02:03'), 3723);
  assert.equal(dt.parseDuration('1d'), 86400);
  assert.equal(dt.parseDuration(45), 45);
  assert.equal(dt.parseDuration('  10S '), 10);
});
test('parseDuration: erros com código estável', () => {
  assert.throws(() => dt.parseDuration(''), code('EMPTY_INPUT'));
  assert.throws(() => dt.parseDuration('abc'), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration('5m5m'), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration('5x'), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration('1:75'), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration(-1), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration(NaN), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration(null), code('INVALID_FORMAT'));
  assert.throws(() => dt.parseDuration('8d'), code('OUT_OF_RANGE'));
});
test('formatDuration', () => {
  assert.equal(dt.formatDuration(3723), '01:02:03');
  assert.equal(dt.formatDuration(0), '00:00:00');
  assert.equal(dt.formatDuration(3723, 'words'), '1h 2m 3s');
  assert.equal(dt.formatDuration(0, 'words'), '0s');
  assert.equal(dt.formatDuration(90061, 'words'), '1d 1h 1m 1s');
  assert.throws(() => dt.formatDuration(-5), code('INVALID_FORMAT'));
  assert.throws(() => dt.formatDuration(5, 'xx'), code('INVALID_FORMAT'));
});
test('createTimer: ciclo completo com relógio falso', () => {
  let t = 1000;
  const timer = dt.createTimer(10, () => t);
  assert.equal(timer.state(), 'idle');
  assert.equal(timer.remaining(), 10);
  timer.start();
  t += 4000;
  assert.equal(timer.remaining(), 6);
  timer.pause();
  t += 50000;
  assert.equal(timer.state(), 'paused');
  assert.equal(timer.remaining(), 6);
  timer.resume();
  t += 6000;
  assert.equal(timer.remaining(), 0);
  assert.equal(timer.state(), 'finished');
  timer.reset();
  assert.equal(timer.state(), 'idle');
  assert.equal(timer.remaining(), 10);
});
test('createTimer: estados inválidos e duração inválida', () => {
  let t = 0;
  const timer = dt.createTimer(5, () => t);
  assert.throws(() => timer.pause(), code('INVALID_STATE'));
  assert.throws(() => timer.resume(), code('INVALID_STATE'));
  timer.start();
  assert.throws(() => timer.start(), code('INVALID_STATE'));
  assert.throws(() => dt.createTimer(0), code('OUT_OF_RANGE'));
  assert.throws(() => dt.createTimer('5'), code('OUT_OF_RANGE'));
});
