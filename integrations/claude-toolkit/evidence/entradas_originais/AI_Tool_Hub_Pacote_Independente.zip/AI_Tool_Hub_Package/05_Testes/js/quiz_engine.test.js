const test = require('node:test');
const assert = require('node:assert/strict');
const { quizEngine: qe } = require('../../01_Ferramentas_Exportaveis/js/index.js');
const code = (c) => (e) => e.name === 'ToolError' && e.code === c;

const quiz = () => ({
  title: 'Capitais',
  questions: [
    { id: 'q1', prompt: 'Capital da França?', options: [{ id: 'a', text: 'Paris' }, { id: 'b', text: 'Roma' }], correct_option_id: 'a', explanation: 'Paris.' },
    { id: 'q2', prompt: 'Capital da Itália?', options: [{ id: 'a', text: 'Paris' }, { id: 'b', text: 'Roma' }], correct_option_id: 'b' }
  ]
});

test('validateQuiz: válido', () => {
  assert.deepEqual(qe.validateQuiz(quiz()), { valid: true, errors: [] });
});
test('validateQuiz: detecta problemas', () => {
  assert.equal(qe.validateQuiz(null).valid, false);
  assert.equal(qe.validateQuiz({ title: 'x', questions: [] }).valid, false);
  const dup = quiz(); dup.questions[1].id = 'q1';
  assert.match(qe.validateQuiz(dup).errors.join(), /duplicado/);
  const bad = quiz(); bad.questions[0].correct_option_id = 'z';
  assert.match(qe.validateQuiz(bad).errors.join(), /correct_option_id/);
  const few = quiz(); few.questions[0].options = [{ id: 'a', text: 'x' }];
  assert.match(qe.validateQuiz(few).errors.join(), /ao menos 2/);
  const notitle = quiz(); notitle.title = ' ';
  assert.match(qe.validateQuiz(notitle).errors.join(), /title/);
});
test('grade: acertos, erros e não respondidas', () => {
  const r = qe.grade(quiz(), { q1: 'a', q2: 'a' });
  assert.equal(r.correct, 1);
  assert.equal(r.total, 2);
  assert.equal(r.score_percent, 50);
  assert.equal(r.results[0].is_correct, true);
  assert.equal(r.results[0].explanation, 'Paris.');
  assert.equal(r.results[1].is_correct, false);
  const none = qe.grade(quiz(), {});
  assert.equal(none.correct, 0);
  assert.equal(none.results[0].answered, false);
});
test('grade: opção inválida e ids desconhecidos', () => {
  const r = qe.grade(quiz(), { q1: 'zzz', extra: 'a' });
  assert.equal(r.results[0].selected_valid, false);
  assert.equal(r.results[0].is_correct, false);
  assert.deepEqual(r.unknown_answer_ids, ['extra']);
});
test('grade: erros e arredondamento', () => {
  assert.throws(() => qe.grade({ title: 'x' }, {}), code('INVALID_QUIZ'));
  assert.throws(() => qe.grade(quiz(), []), code('INVALID_ANSWERS'));
  assert.throws(() => qe.grade(quiz(), null), code('INVALID_ANSWERS'));
  const q3 = quiz();
  q3.questions.push({ id: 'q3', prompt: 'p', options: [{ id: 'a', text: 'x' }, { id: 'b', text: 'y' }], correct_option_id: 'a' });
  assert.equal(qe.grade(q3, { q1: 'a' }).score_percent, 33.3);
});
