from _helpers import Base
from ai_tool_hub import quiz_engine as qe


def quiz():
    return {"title": "Capitais", "questions": [
        {"id": "q1", "prompt": "Capital da França?", "options": [{"id": "a", "text": "Paris"}, {"id": "b", "text": "Roma"}],
         "correct_option_id": "a", "explanation": "Paris."},
        {"id": "q2", "prompt": "Capital da Itália?", "options": [{"id": "a", "text": "Paris"}, {"id": "b", "text": "Roma"}],
         "correct_option_id": "b"}]}


class TestValidate(Base):
    def test_valido(self):
        self.assertEqual(qe.validate_quiz(quiz()), {"valid": True, "errors": []})

    def test_problemas(self):
        self.assertFalse(qe.validate_quiz(None)["valid"])
        self.assertFalse(qe.validate_quiz({"title": "x", "questions": []})["valid"])
        dup = quiz(); dup["questions"][1]["id"] = "q1"
        self.assertIn("duplicado", " ".join(qe.validate_quiz(dup)["errors"]))
        bad = quiz(); bad["questions"][0]["correct_option_id"] = "z"
        self.assertIn("correct_option_id", " ".join(qe.validate_quiz(bad)["errors"]))
        few = quiz(); few["questions"][0]["options"] = [{"id": "a", "text": "x"}]
        self.assertIn("ao menos 2", " ".join(qe.validate_quiz(few)["errors"]))
        nt = quiz(); nt["title"] = " "
        self.assertIn("title", " ".join(qe.validate_quiz(nt)["errors"]))


class TestGrade(Base):
    def test_acertos_erros_nao_respondidas(self):
        r = qe.grade(quiz(), {"q1": "a", "q2": "a"})
        self.assertEqual((r["correct"], r["total"], r["score_percent"]), (1, 2, 50))
        self.assertTrue(r["results"][0]["is_correct"])
        self.assertEqual(r["results"][0]["explanation"], "Paris.")
        self.assertFalse(r["results"][1]["is_correct"])
        none = qe.grade(quiz(), {})
        self.assertEqual(none["correct"], 0)
        self.assertFalse(none["results"][0]["answered"])

    def test_opcao_invalida_e_ids_desconhecidos(self):
        r = qe.grade(quiz(), {"q1": "zzz", "extra": "a"})
        self.assertFalse(r["results"][0]["selected_valid"])
        self.assertFalse(r["results"][0]["is_correct"])
        self.assertEqual(r["unknown_answer_ids"], ["extra"])

    def test_erros_e_arredondamento(self):
        self.assertCode("INVALID_QUIZ", qe.grade, {"title": "x"}, {})
        self.assertCode("INVALID_ANSWERS", qe.grade, quiz(), [])
        self.assertCode("INVALID_ANSWERS", qe.grade, quiz(), None)
        q3 = quiz()
        q3["questions"].append({"id": "q3", "prompt": "p", "options": [{"id": "a", "text": "x"}, {"id": "b", "text": "y"}],
                                "correct_option_id": "a"})
        self.assertEqual(qe.grade(q3, {"q1": "a"})["score_percent"], 33.3)
