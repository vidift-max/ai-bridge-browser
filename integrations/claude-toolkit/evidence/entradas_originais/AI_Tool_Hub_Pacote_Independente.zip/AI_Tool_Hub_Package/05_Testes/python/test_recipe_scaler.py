import copy

from _helpers import Base
from ai_tool_hub import recipe_scaler as rs


def recipe():
    return {"title": "Panqueca", "base_servings": 4, "ingredients": [
        {"name": "Farinha", "amount": 2, "unit": "cup"},
        {"name": "Ovos", "amount": 2, "unit": None},
        {"name": "Leite", "amount": 500, "unit": "ml"}]}


class TestConvert(Base):
    def test_validas(self):
        self.assertEqual(rs.convert(1, "cup", "ml"), 236.588237)
        self.assertEqual(rs.convert(1, "tbsp", "tsp"), 3)
        self.assertEqual(rs.convert(1, "kg", "g"), 1000)
        self.assertEqual(rs.convert(1, "lb", "oz"), 16)
        self.assertEqual(rs.convert(1, "Teaspoon", "TSP"), 1)
        self.assertEqual(rs.convert(0, "g", "oz"), 0)

    def test_erros(self):
        self.assertCode("INCOMPATIBLE_UNITS", rs.convert, 1, "cup", "g")
        self.assertCode("UNKNOWN_UNIT", rs.convert, 1, "xyz", "g")
        self.assertCode("UNKNOWN_UNIT", rs.convert, 1, 5, "g")
        self.assertCode("INVALID_AMOUNT", rs.convert, -1, "g", "kg")
        self.assertCode("INVALID_AMOUNT", rs.convert, "1", "g", "kg")
        self.assertCode("UNKNOWN_UNIT", rs.convert, 1, "__proto__", "g")


class TestScale(Base):
    def test_dobra_sem_alterar_entrada(self):
        r = recipe()
        out = rs.scale_recipe(r, 8)
        self.assertEqual(out["scale_factor"], 2)
        self.assertEqual(out["base_servings"], 8)
        self.assertEqual([i["amount"] for i in out["ingredients"]], [4, 4, 1000])
        self.assertIsNone(out["ingredients"][1]["unit"])
        self.assertEqual(r, recipe())

    def test_fracao(self):
        out = rs.scale_recipe(recipe(), 1)
        self.assertEqual(out["scale_factor"], 0.25)
        self.assertEqual(out["ingredients"][0]["amount"], 0.5)

    def test_erros(self):
        self.assertCode("INVALID_RECIPE", rs.scale_recipe, None, 2)
        self.assertCode("INVALID_RECIPE", rs.scale_recipe, {"base_servings": 0, "ingredients": [{"name": "a", "amount": 1}]}, 2)
        self.assertCode("INVALID_RECIPE", rs.scale_recipe, {"base_servings": 2, "ingredients": []}, 2)
        self.assertCode("INVALID_SERVINGS", rs.scale_recipe, recipe(), 0)
        self.assertCode("INVALID_RECIPE", rs.scale_recipe, {"base_servings": 2, "ingredients": [{"name": "", "amount": 1}]}, 2)
        self.assertCode("INVALID_AMOUNT", rs.scale_recipe, {"base_servings": 2, "ingredients": [{"name": "x", "amount": -1}]}, 2)
        self.assertCode("UNKNOWN_UNIT", rs.scale_recipe, {"base_servings": 2, "ingredients": [{"name": "x", "amount": 1, "unit": "zzz"}]}, 2)

    def test_format_amount(self):
        self.assertEqual(rs.format_amount(1.5), "1.5")
        self.assertEqual(rs.format_amount(100), "100")
        self.assertEqual(rs.format_amount(0), "0")
        self.assertEqual(rs.format_amount(0.333333), "0.33")
        self.assertCode("INVALID_AMOUNT", rs.format_amount, float("nan"))
