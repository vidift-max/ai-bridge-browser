import os
import sys
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "01_Ferramentas_Exportaveis", "python"))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from ai_tool_hub import ToolError  # noqa: E402


class Base(unittest.TestCase):
    def assertCode(self, code, fn, *args, **kwargs):
        with self.assertRaises(ToolError) as ctx:
            fn(*args, **kwargs)
        self.assertEqual(ctx.exception.code, code)
