import re

from _helpers import Base
from ai_tool_hub import svg_chart as sc


def count(s, pattern):
    return len(re.findall(pattern, s))


class TestChart(Base):
    def test_nice_max(self):
        self.assertEqual(sc.nice_max(0), 1)
        self.assertEqual(sc.nice_max(7), 10)
        self.assertEqual(sc.nice_max(120), 200)
        self.assertEqual(sc.nice_max(0.3), 0.5)
        self.assertEqual(sc.nice_max(50), 50)

    def test_barras(self):
        svg = sc.render_chart({"type": "bar", "title": "Vendas", "labels": ["Jan", "Fev", "Mar"],
                               "series": [{"name": "A", "values": [10, 20, 30]}]})
        self.assertTrue(svg.startswith('<svg xmlns="http://www.w3.org/2000/svg"'))
        self.assertTrue(svg.endswith("</svg>"))
        self.assertEqual(count(svg, r"<rect x="), 3)
        self.assertIn("<title>Vendas</title>", svg)
        self.assertEqual(count(svg, r"<line "), 5)

    def test_linhas_duas_series(self):
        svg = sc.render_chart({"type": "line", "labels": ["a", "b"],
                               "series": [{"name": "X", "values": [1, 2]}, {"name": "Y", "values": [2, 1]}]})
        self.assertEqual(count(svg, r"<polyline "), 2)
        self.assertEqual(count(svg, r"<circle "), 4)
        self.assertIn(">X</text>", svg)

    def test_escapa_texto(self):
        svg = sc.render_chart({"type": "bar", "title": "<script>alert(1)</script>", "labels": ["<b>"],
                               "series": [{"values": [1]}]})
        self.assertNotIn("<script>", svg)
        self.assertNotIn("<b>", svg)
        self.assertIn("&lt;script&gt;", svg)

    def test_zeros(self):
        svg = sc.render_chart({"type": "bar", "labels": ["a"], "series": [{"values": [0]}]})
        self.assertIn("<svg", svg)
        self.assertNotIn("nan", svg.lower())

    def test_erros(self):
        ok = {"type": "bar", "labels": ["a", "b"], "series": [{"values": [1, 2]}]}
        self.assertCode("INVALID_SPEC", sc.render_chart, None)
        self.assertCode("INVALID_SPEC", sc.render_chart, {**ok, "type": "pie"})
        self.assertCode("INVALID_SPEC", sc.render_chart, {**ok, "labels": []})
        self.assertCode("INVALID_SPEC", sc.render_chart, {**ok, "series": []})
        self.assertCode("LENGTH_MISMATCH", sc.render_chart, {**ok, "series": [{"values": [1]}]})
        self.assertCode("NEGATIVE_VALUE", sc.render_chart, {**ok, "series": [{"values": [1, -2]}]})
        self.assertCode("INVALID_VALUE", sc.render_chart, {**ok, "series": [{"values": [1, "x"]}]})
        self.assertCode("INVALID_SIZE", sc.render_chart, {**ok, "width": 50})
        self.assertCode("INVALID_SPEC", sc.render_chart, {**ok, "series": [{"values": [1, 2]}] * 7})
