from _helpers import Base
from ai_tool_hub import duration_timer as dt


class TestParse(Base):
    def test_formatos_validos(self):
        for text, expected in [("90", 90), ("5m", 300), ("1h30m", 5400), ("2m 30s", 150), ("1:30", 90),
                               ("1:02:03", 3723), ("1d", 86400), (45, 45), ("  10S ", 10)]:
            self.assertEqual(dt.parse_duration(text), expected, text)

    def test_erros(self):
        self.assertCode("EMPTY_INPUT", dt.parse_duration, "")
        for bad in ["abc", "5m5m", "5x", "1:75"]:
            self.assertCode("INVALID_FORMAT", dt.parse_duration, bad)
        for bad in [-1, float("nan"), None, True]:
            self.assertCode("INVALID_FORMAT", dt.parse_duration, bad)
        self.assertCode("OUT_OF_RANGE", dt.parse_duration, "8d")


class TestFormat(Base):
    def test_format(self):
        self.assertEqual(dt.format_duration(3723), "01:02:03")
        self.assertEqual(dt.format_duration(0), "00:00:00")
        self.assertEqual(dt.format_duration(3723, "words"), "1h 2m 3s")
        self.assertEqual(dt.format_duration(0, "words"), "0s")
        self.assertEqual(dt.format_duration(90061, "words"), "1d 1h 1m 1s")
        self.assertCode("INVALID_FORMAT", dt.format_duration, -5)
        self.assertCode("INVALID_FORMAT", dt.format_duration, 5, "xx")


class TestTimer(Base):
    def test_ciclo_completo(self):
        t = [1000.0]
        timer = dt.Timer(10, clock=lambda: t[0])
        self.assertEqual(timer.state(), "idle")
        self.assertEqual(timer.remaining(), 10)
        timer.start()
        t[0] += 4
        self.assertEqual(timer.remaining(), 6)
        timer.pause()
        t[0] += 50
        self.assertEqual(timer.state(), "paused")
        self.assertEqual(timer.remaining(), 6)
        timer.resume()
        t[0] += 6
        self.assertEqual(timer.remaining(), 0)
        self.assertEqual(timer.state(), "finished")
        timer.reset()
        self.assertEqual(timer.state(), "idle")
        self.assertEqual(timer.remaining(), 10)

    def test_estados_invalidos(self):
        timer = dt.Timer(5, clock=lambda: 0.0)
        self.assertCode("INVALID_STATE", timer.pause)
        self.assertCode("INVALID_STATE", timer.resume)
        timer.start()
        self.assertCode("INVALID_STATE", timer.start)
        self.assertCode("OUT_OF_RANGE", dt.Timer, 0)
        self.assertCode("OUT_OF_RANGE", dt.Timer, "5")
