import contextlib
import io
import json
import os
import tempfile

from _helpers import Base
from ai_tool_hub.__main__ import main


def run(argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = main(argv)
    return code, out.getvalue(), err.getvalue()


class TestCli(Base):
    def test_parse_e_convert(self):
        self.assertEqual(run(["parse-duration", "1h30m"])[:2], (0, "5400.0\n"))
        self.assertEqual(run(["convert", "1", "cup", "ml"])[:2], (0, "236.588237\n"))

    def test_erro_retorna_2_com_codigo(self):
        code, _, err = run(["parse-duration", "abc"])
        self.assertEqual(code, 2)
        self.assertTrue(err.startswith("INVALID_FORMAT:"))
        self.assertEqual(run(["link-card", "javascript:alert(1)"])[0], 2)

    def test_arquivos_json(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "spec.json")
            with open(p, "w", encoding="utf-8") as fh:
                json.dump({"type": "bar", "labels": ["a"], "series": [{"values": [1]}]}, fh)
            code, out, _ = run(["chart", p])
            self.assertEqual(code, 0)
            self.assertTrue(out.startswith("<svg"))
            self.assertEqual(run(["chart", os.path.join(d, "nao_existe.json")])[0], 2)
