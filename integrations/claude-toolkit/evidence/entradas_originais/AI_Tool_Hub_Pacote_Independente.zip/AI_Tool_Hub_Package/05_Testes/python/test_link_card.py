from _helpers import Base
from ai_tool_hub import link_card as lc


class TestLinkCard(Base):
    def test_normaliza(self):
        r = lc.build_link_card({"url": "HTTPS://Example.COM/a?b=1#c"})
        self.assertEqual(r["url"], "https://example.com/a?b=1#c")
        self.assertEqual(r["host"], "example.com")
        self.assertEqual(r["title"], "example.com")
        self.assertEqual(lc.build_link_card({"url": "https://example.com"})["url"], "https://example.com/")
        self.assertEqual(lc.build_link_card({"url": "https://example.com:443/x"})["url"], "https://example.com/x")
        self.assertEqual(lc.build_link_card({"url": "http://example.com:8080/x"})["url"], "http://example.com:8080/x")

    def test_html_escapado(self):
        r = lc.build_link_card({"url": "https://example.com", "title": "<img src=x onerror=alert(1)>",
                                "description": 'a & b "c"'})
        self.assertNotIn("<img", r["html"])
        self.assertIn('rel="noopener noreferrer nofollow"', r["html"])
        self.assertIn("a &amp; b &quot;c&quot;", r["html"])

    def test_esquemas_perigosos(self):
        for url in ["javascript:alert(1)", "data:text/html,<b>x</b>", "file:///etc/passwd", "JaVaScRiPt:alert(1)"]:
            self.assertCode("UNSUPPORTED_SCHEME", lc.build_link_card, {"url": url})

    def test_outros_erros(self):
        self.assertCode("EMPTY_INPUT", lc.build_link_card, None)
        self.assertCode("EMPTY_INPUT", lc.build_link_card, {"url": "  "})
        self.assertCode("INVALID_URL", lc.build_link_card, {"url": "example.com"})
        self.assertCode("INVALID_URL", lc.build_link_card, {"url": "https://exa mple.com"})
        self.assertCode("INVALID_URL", lc.build_link_card, {"url": "https:///x"})
        self.assertCode("CREDENTIALS_IN_URL", lc.build_link_card, {"url": "https://user:pw@example.com/"})
        self.assertCode("INVALID_URL", lc.build_link_card, {"url": "https://example.com/" + "a" * 2100})

    def test_ipv6_host_com_colchetes(self):
        r = lc.build_link_card({"url": "http://[::1]:8080/x"})
        self.assertEqual(r["host"], "[::1]")
        self.assertEqual(r["url"], "http://[::1]:8080/x")
