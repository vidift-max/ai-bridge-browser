#!/usr/bin/env node
/*
 * Simulação do carregamento "como navegador" — NÃO substitui um teste em navegador real.
 * Carrega os arquivos de tools/ com vm SEM `module`/`require` (ramo de navegador do UMD),
 * executa o script de smoke_test.html e os cliques de app.js contra um DOM falso mínimo.
 * Uso: node 05_Testes/simulacao_navegador.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('node:assert/strict');

const JS_DIR = path.join(__dirname, '..', '01_Ferramentas_Exportaveis', 'js');
const read = (f) => fs.readFileSync(path.join(JS_DIR, f), 'utf8');

class El {
  constructor(id) { this.id = id; this.value = ''; this.children = []; this.textContent = ''; this.innerHTML = ''; this.className = ''; this.onclick = null; }
  appendChild(c) { this.children.push(c); return c; }
  all() { return this.textContent + this.innerHTML + this.children.map((c) => (c.all ? c.all() : c.text || '')).join('|'); }
}
function makeWindow() {
  const els = {};
  const document = {
    getElementById: (id) => (els[id] = els[id] || new El(id)),
    createElement: () => new El(''),
    createTextNode: (text) => ({ text }),
    querySelector: () => null
  };
  const ctx = { document, setInterval: () => 1, clearInterval: () => {}, console, URL }; // URL existe em todo navegador moderno; o vm do Node não a expõe
  ctx.window = ctx; ctx.self = ctx;
  vm.createContext(ctx);
  ['core.js', 'duration_timer.js', 'recipe_scaler.js', 'quiz_engine.js', 'svg_chart.js', 'link_card.js'].forEach((f) =>
    vm.runInContext(read('tools/' + f), ctx, { filename: f }));
  return { ctx, els, document };
}

// 1) Ramo de navegador do UMD
{
  const { ctx } = makeWindow();
  for (const k of ['core', 'durationTimer', 'recipeScaler', 'quizEngine', 'svgChart', 'linkCard']) {
    assert.ok(ctx.AIToolHub[k], 'AIToolHub.' + k + ' ausente');
  }
  console.log('OK  UMD (ramo de navegador): 6 módulos registrados em window.AIToolHub');
}
// 2) Script do smoke_test.html
{
  const { ctx, els } = makeWindow();
  const html = fs.readFileSync(path.join(JS_DIR, 'smoke_test.html'), 'utf8');
  const inline = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]).pop();
  vm.runInContext(inline, ctx, { filename: 'smoke_test.html' });
  const summary = els.summary.textContent;
  assert.match(summary, /^(\d+) de \1 verificações passaram\.$/, summary);
  const bad = els.list.children.filter((li) => li.className === 'bad');
  assert.equal(bad.length, 0);
  console.log('OK  smoke_test.html: ' + summary);
}
// 3) Cliques de app.js
{
  const { ctx, els } = makeWindow();
  Object.assign(els, {});
  const g = (id) => ctx.document.getElementById(id);
  g('dur').value = '2m30s'; g('rServ').value = '6'; g('cAmt').value = '1'; g('cFrom').value = 'cup'; g('cTo').value = 'ml';
  g('lUrl').value = 'https://example.com/x'; g('lTitle').value = 'T'; g('lDesc').value = 'D';
  vm.runInContext(read('app.js'), ctx, { filename: 'app.js' });
  g('tStart').onclick(); assert.match(g('tOut').all(), /running/); assert.equal(g('clock').textContent, '00:02:30');
  g('tPause').onclick(); assert.match(g('tOut').all(), /paused/);
  g('tResume').onclick(); g('tReset').onclick(); assert.match(g('tOut').all(), /idle/);
  g('tPause').onclick(); assert.match(g('tOut').all(), /INVALID_STATE/);
  g('rGo').onclick(); assert.match(g('rOut').all(), /3 Farinha|3 cup Farinha/);
  g('cGo').onclick(); assert.match(g('rOut').all(), /236\.59 ml/);
  g('qLoad').onclick(); assert.equal(g('qBox').children.length, 2);
  g('qGrade').onclick(); assert.match(g('qOut').all(), /Acertos: 0 de 2/);
  g('cDraw').onclick(); assert.match(g('cOut').innerHTML, /^<svg/);
  g('lGo').onclick(); assert.equal(g('lOut').children[0].href, 'https://example.com/x');
  g('lUrl').value = 'javascript:alert(1)'; g('lGo').onclick(); assert.match(g('lOut').all(), /UNSUPPORTED_SCHEME/);
  console.log('OK  app.js: 5 ferramentas respondem aos cliques (DOM falso)');
}
// 4) Versão de arquivo único (index_standalone.html): scripts embutidos, mesma lógica
{
  const { ctx } = (function () { const w = makeWindow(); return w; })();
  const fresh = (() => {
    const els = {};
    const document = {
      getElementById: (id) => (els[id] = els[id] || new El(id)),
      createElement: () => new El(''), createTextNode: (text) => ({ text }), querySelector: () => null
    };
    const c = { document, setInterval: () => 1, clearInterval: () => {}, console, URL };
    c.window = c; c.self = c; vm.createContext(c);
    return c;
  })();
  const html = fs.readFileSync(path.join(JS_DIR, 'index_standalone.html'), 'utf8');
  assert.ok(!/<script src=/.test(html), 'standalone ainda referencia scripts externos');
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1]);
  assert.equal(scripts.length, 1);
  const g = (id) => fresh.document.getElementById(id);
  g('dur').value = '1m'; g('rServ').value = '2'; g('cAmt').value = '1'; g('cFrom').value = 'kg'; g('cTo').value = 'g';
  g('lUrl').value = 'https://example.com'; g('lTitle').value = ''; g('lDesc').value = '';
  vm.runInContext(scripts[0], fresh, { filename: 'index_standalone.html' });
  g('tStart').onclick(); assert.equal(g('clock').textContent, '00:01:00');
  g('cGo').onclick(); assert.match(g('rOut').all(), /1000 g/);
  g('cDraw').onclick(); assert.match(g('cOut').innerHTML, /^<svg/);
  g('lGo').onclick(); assert.equal(g('lOut').children[0].href, 'https://example.com/');
  console.log('OK  index_standalone.html: arquivo único funciona (DOM falso)');
}
// 5) smoke_test_standalone.html: bloco de ferramentas + script de verificação, na ordem do arquivo
{
  const els = {};
  const document = { getElementById: (id) => (els[id] = els[id] || new El(id)), createElement: () => new El('') };
  const c = { document, console, URL }; c.window = c; c.self = c; vm.createContext(c);
  const html = fs.readFileSync(path.join(JS_DIR, 'smoke_test_standalone.html'), 'utf8');
  assert.ok(!/<script src=/.test(html));
  [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].forEach((m) => vm.runInContext(m[1], c));
  assert.match(els.summary.textContent, /^(\d+) de \1 verificações passaram\.$/, els.summary.textContent);
  console.log('OK  smoke_test_standalone.html: ' + els.summary.textContent);
}
console.log('\nATENÇÃO: simulação em Node. Falta validar em navegador real (Chrome/Android).');
