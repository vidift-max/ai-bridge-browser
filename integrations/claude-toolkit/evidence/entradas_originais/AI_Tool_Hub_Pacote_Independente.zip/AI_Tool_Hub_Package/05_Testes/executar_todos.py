#!/usr/bin/env python3
"""Executa TODOS os testes do pacote e mostra um resumo.

Uso:
  python3 05_Testes/executar_todos.py                       # só executa
  python3 05_Testes/executar_todos.py --relatorio saida.md  # também grava relatório com as saídas reais

Etapas: testes JS (Node.js), testes Python (unittest), paridade JS x Python, simulação de navegador.
Se o Node.js não estiver instalado, as etapas que o exigem são marcadas como PULADAS (não como aprovadas).
"""
import argparse
import datetime
import glob
import os
import platform
import re
import shutil
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
NODE = shutil.which("node")


def run(cmd, cwd=None):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr)


def etapas():
    js_files = sorted(glob.glob(os.path.join(AQUI, "js", "*.test.js")))
    return [
        ("Testes JavaScript (node --test)", bool(NODE), [NODE, "--test"] + js_files if NODE else None, None),
        ("Testes Python (unittest)", True, [sys.executable, "-m", "unittest", "discover", "-v"], os.path.join(AQUI, "python")),
        ("Paridade JS x Python", bool(NODE), [sys.executable, os.path.join(AQUI, "paridade_js_python.py")], None),
        ("Simulação de navegador (DOM falso)", bool(NODE), [NODE, os.path.join(AQUI, "simulacao_navegador.js")], None),
    ]


def resumo(nome, saida):
    if nome.startswith("Testes JavaScript"):
        g = lambda k: re.search(r"^# %s (\d+)" % k, saida, re.M)
        if g("tests") and g("pass") and g("fail"):
            return f"{g('pass').group(1)} aprovados, {g('fail').group(1)} falhas, de {g('tests').group(1)}"
    if nome.startswith("Testes Python"):
        m = re.search(r"Ran (\d+) tests?", saida)
        ok = re.search(r"^OK\s*$", saida, re.M)
        if m:
            return f"{m.group(1)} executados, {'todos aprovados' if ok else 'COM FALHAS'}"
    if nome.startswith("Paridade"):
        m = re.search(r"Paridade JS x Python: (\d+)/(\d+)", saida)
        if m:
            return f"{m.group(1)} de {m.group(2)} casos idênticos"
    if nome.startswith("Simulação"):
        return f"{len(re.findall(r'^OK ', saida, re.M))} verificações OK"
    return ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--relatorio", help="caminho de um arquivo .md para gravar o relatório")
    args = ap.parse_args()
    linhas, brutos, falhou = [], [], False
    for nome, disponivel, cmd, cwd in etapas():
        if not disponivel:
            linhas.append((nome, "PULADA (Node.js não encontrado)", ""))
            continue
        code, saida = run(cmd, cwd)
        status = "APROVADA" if code == 0 else "FALHOU"
        falhou = falhou or code != 0
        linhas.append((nome, status, resumo(nome, saida)))
        brutos.append((nome, " ".join(os.path.basename(c) if os.path.isabs(c) and i else c for i, c in enumerate(cmd[:3])), code, saida))
    print("RESUMO")
    for nome, status, det in linhas:
        print(f"  [{status}] {nome} {('— ' + det) if det else ''}")
    if args.relatorio:
        agora = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        node_v = run([NODE, "--version"])[1].strip() if NODE else "não instalado"
        with open(args.relatorio, "w", encoding="utf-8") as fh:
            fh.write("# Relatório de testes — execução real\n\n")
            fh.write(f"- Data: {agora}\n- Sistema: {platform.platform()}\n- Python: {platform.python_version()}\n- Node.js: {node_v}\n")
            fh.write("- Ambiente: contêiner Linux sem navegador e sem aparelho Android\n\n")
            fh.write("## Resumo\n\n| Etapa | Resultado | Detalhe |\n|---|---|---|\n")
            for nome, status, det in linhas:
                fh.write(f"| {nome} | {status} | {det} |\n")
            fh.write("\n## O que NÃO foi testado\n\n- Navegador real e Android (Chrome, Firefox, WebView): **não executado**. `smoke_test.html` existe para você rodar.\n")
            fh.write("- Python 3.9–3.11 e Node.js anterior à v22.\n- Acessibilidade, desempenho e segurança por terceiros.\n\n")
            fh.write("## Saídas brutas\n")
            for nome, cmd, code, saida in brutos:
                fh.write(f"\n### {nome}\n\nComando: `{cmd} ...` — código de saída: {code}\n\n```text\n{saida.strip()}\n```\n")
    return 1 if falhou else 0


if __name__ == "__main__":
    sys.exit(main())
