#!/usr/bin/env python3
"""Gera MANIFESTO.json e MANIFESTO.md (arquivo, ferramenta, categoria, linguagem, finalidade, tamanho, SHA-256).

Falha se existir arquivo sem descrição ou descrição de arquivo inexistente (para o manifesto nunca ficar desatualizado).
Uso: python3 05_Testes/gerar_manifesto.py
"""
import hashlib
import json
import os
import sys

RAIZ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
IMPL, DEMO, AUX, CONF, DOC, EXEMPLO, SAIDA, TESTE, REL = (
    "implementacao_original", "interface_demo", "script_auxiliar", "configuracao", "documentacao",
    "exemplo", "saida_de_exemplo", "teste", "relatorio")
J, P = "01_Ferramentas_Exportaveis/js/", "01_Ferramentas_Exportaveis/python/"

ARQUIVOS = [
    ("README.md", "-", DOC, "Markdown", "Visão geral, instruções para computador e Android"),
    (J + "tools/core.js", "(apoio)", IMPL, "JavaScript", "Erro comum (ToolError) e utilitários de escape/limpeza de texto"),
    (J + "tools/duration_timer.js", "duration_timer", IMPL, "JavaScript", "Interpretar/formatar durações e cronômetro regressivo"),
    (J + "tools/recipe_scaler.js", "recipe_scaler", IMPL, "JavaScript", "Escalar receitas e converter unidades"),
    (J + "tools/quiz_engine.js", "quiz_engine", IMPL, "JavaScript", "Validar e corrigir quizzes"),
    (J + "tools/svg_chart.js", "svg_chart", IMPL, "JavaScript", "Gerar gráficos SVG de barras e linhas"),
    (J + "tools/link_card.js", "link_card", IMPL, "JavaScript", "Validar URL e montar cartão de link"),
    (J + "index.js", "(todas)", AUX, "JavaScript", "Ponto de entrada para Node.js (require)"),
    (J + "app.js", "(todas)", DEMO, "JavaScript", "Liga a interface de demonstração às ferramentas"),
    (J + "index.html", "(todas)", DEMO, "HTML/CSS", "Página de demonstração (carrega tools/*.js)"),
    (J + "index_standalone.html", "(todas)", DEMO, "HTML/CSS/JS", "Demonstração em arquivo único (gerado por build_standalone.py)"),
    (J + "smoke_test.html", "(todas)", TESTE, "HTML/JS", "Teste rápido para rodar no navegador (carrega tools/*.js)"),
    (J + "smoke_test_standalone.html", "(todas)", TESTE, "HTML/JS", "Teste rápido em arquivo único, indicado para Android"),
    (J + "build_standalone.py", "-", AUX, "Python", "Gera as versões de arquivo único das páginas"),
    (P + "ai_tool_hub/__init__.py", "(apoio)", IMPL, "Python", "Exporta as ferramentas do pacote"),
    (P + "ai_tool_hub/__main__.py", "(todas)", IMPL, "Python", "Linha de comando: python -m ai_tool_hub"),
    (P + "ai_tool_hub/errors.py", "(apoio)", IMPL, "Python", "Erro comum (ToolError) e utilitários"),
    (P + "ai_tool_hub/duration_timer.py", "duration_timer", IMPL, "Python", "Interpretar/formatar durações e cronômetro regressivo"),
    (P + "ai_tool_hub/recipe_scaler.py", "recipe_scaler", IMPL, "Python", "Escalar receitas e converter unidades"),
    (P + "ai_tool_hub/quiz_engine.py", "quiz_engine", IMPL, "Python", "Validar e corrigir quizzes"),
    (P + "ai_tool_hub/svg_chart.py", "svg_chart", IMPL, "Python", "Gerar gráficos SVG de barras e linhas"),
    (P + "ai_tool_hub/link_card.py", "link_card", IMPL, "Python", "Validar URL e montar cartão de link"),
    (P + "pyproject.toml", "-", CONF, "TOML", "Metadados para instalar com pip (sem dependências)"),
    (P + "requirements.txt", "-", CONF, "Texto", "Dependências de execução (nenhuma)"),
    (P + "requirements-dev.txt", "-", CONF, "Texto", "Dependência opcional de desenvolvimento (pytest)"),
    ("02_Documentacao_Visual/README.md", "-", DOC, "Markdown", "Por que não há screenshots e roteiro para capturá-los"),
    ("03_APIs_e_Integracoes/API.md", "(todas)", DOC, "Markdown", "Entradas, saídas, erros, permissões e limitações"),
    ("04_Exemplos_de_Uso/exemplo_js.js", "(todas)", EXEMPLO, "JavaScript", "Exemplo de uso em Node.js"),
    ("04_Exemplos_de_Uso/exemplo_python.py", "(todas)", EXEMPLO, "Python", "Exemplo de uso em Python"),
    ("04_Exemplos_de_Uso/receita.json", "recipe_scaler", EXEMPLO, "JSON", "Receita fictícia de exemplo"),
    ("04_Exemplos_de_Uso/quiz.json", "quiz_engine", EXEMPLO, "JSON", "Quiz fictício de exemplo"),
    ("04_Exemplos_de_Uso/respostas.json", "quiz_engine", EXEMPLO, "JSON", "Respostas de exemplo"),
    ("04_Exemplos_de_Uso/grafico.json", "svg_chart", EXEMPLO, "JSON", "Especificação de gráfico de exemplo"),
    ("04_Exemplos_de_Uso/saida_grafico_js.svg", "svg_chart", SAIDA, "SVG", "Saída gerada pela versão JS ao rodar o exemplo"),
    ("04_Exemplos_de_Uso/saida_grafico_py.svg", "svg_chart", SAIDA, "SVG", "Saída gerada pela versão Python ao rodar o exemplo"),
    ("05_Testes/executar_todos.py", "(todas)", TESTE, "Python", "Executa todos os testes e grava o relatório"),
    ("05_Testes/paridade_js_python.py", "(todas)", TESTE, "Python", "Compara as respostas das versões JS e Python"),
    ("05_Testes/simulacao_navegador.js", "(todas)", TESTE, "JavaScript", "Simula o carregamento no navegador com DOM falso"),
    ("05_Testes/gerar_manifesto.py", "-", AUX, "Python", "Gera este manifesto"),
    ("05_Testes/RELATORIO_TESTES.md", "(todas)", REL, "Markdown", "Resultado real da última execução dos testes"),
    ("05_Testes/js/duration_timer.test.js", "duration_timer", TESTE, "JavaScript", "Testes automatizados (node:test)"),
    ("05_Testes/js/recipe_scaler.test.js", "recipe_scaler", TESTE, "JavaScript", "Testes automatizados (node:test)"),
    ("05_Testes/js/quiz_engine.test.js", "quiz_engine", TESTE, "JavaScript", "Testes automatizados (node:test)"),
    ("05_Testes/js/svg_chart.test.js", "svg_chart", TESTE, "JavaScript", "Testes automatizados (node:test)"),
    ("05_Testes/js/link_card.test.js", "link_card", TESTE, "JavaScript", "Testes automatizados (node:test)"),
    ("05_Testes/python/_helpers.py", "(apoio)", TESTE, "Python", "Auxiliar dos testes Python"),
    ("05_Testes/python/test_duration_timer.py", "duration_timer", TESTE, "Python", "Testes automatizados (unittest)"),
    ("05_Testes/python/test_recipe_scaler.py", "recipe_scaler", TESTE, "Python", "Testes automatizados (unittest)"),
    ("05_Testes/python/test_quiz_engine.py", "quiz_engine", TESTE, "Python", "Testes automatizados (unittest)"),
    ("05_Testes/python/test_svg_chart.py", "svg_chart", TESTE, "Python", "Testes automatizados (unittest)"),
    ("05_Testes/python/test_link_card.py", "link_card", TESTE, "Python", "Testes automatizados (unittest)"),
    ("05_Testes/python/test_cli.py", "(todas)", TESTE, "Python", "Testes da linha de comando"),
    ("06_Limitacoes_e_Permissoes/LIMITACOES.md", "-", DOC, "Markdown", "O que não foi exportado, o que falta e limites da verificação"),
    ("06_Limitacoes_e_Permissoes/PERMISSOES.md", "-", DOC, "Markdown", "Permissões, rede, armazenamento e dados"),
]
IGNORAR = {"MANIFESTO.json", "MANIFESTO.md"}


def main():
    existentes = set()
    for d, dirs, files in os.walk(RAIZ):
        dirs[:] = [x for x in dirs if x != "__pycache__"]
        for f in files:
            rel = os.path.relpath(os.path.join(d, f), RAIZ).replace(os.sep, "/")
            if rel not in IGNORAR and not f.endswith(".pyc"):
                existentes.add(rel)
    descritos = {a[0] for a in ARQUIVOS}
    if existentes - descritos or descritos - existentes:
        print("Sem descrição:", sorted(existentes - descritos))
        print("Descritos mas inexistentes:", sorted(descritos - existentes))
        return 1
    itens = []
    for caminho, ferramenta, cat, ling, fin in sorted(ARQUIVOS):
        with open(os.path.join(RAIZ, caminho), "rb") as fh:
            dados = fh.read()
        itens.append({"arquivo": caminho, "ferramenta": ferramenta, "categoria": cat, "linguagem": ling,
                      "finalidade": fin, "bytes": len(dados), "sha256": hashlib.sha256(dados).hexdigest()})
    with open(os.path.join(RAIZ, "MANIFESTO.json"), "w", encoding="utf-8") as fh:
        json.dump({"pacote": "AI Tool Hub — pacote independente", "versao": "0.1.0", "arquivos": itens}, fh,
                  ensure_ascii=False, indent=2)
    with open(os.path.join(RAIZ, "MANIFESTO.md"), "w", encoding="utf-8") as fh:
        fh.write("# Manifesto de arquivos\n\nCategorias: `implementacao_original` (ferramenta escrita para este pacote), "
                 "`interface_demo`, `script_auxiliar`, `configuracao`, `documentacao`, `exemplo` (não é ferramenta), "
                 "`saida_de_exemplo`, `teste`, `relatorio`. SHA-256 completo em `MANIFESTO.json`. "
                 "O próprio manifesto não tem hash listado.\n\n"
                 "| Arquivo | Ferramenta | Categoria | Linguagem | Finalidade | SHA-256 (início) |\n|---|---|---|---|---|---|\n")
        for i in itens:
            fh.write(f"| `{i['arquivo']}` | {i['ferramenta']} | {i['categoria']} | {i['linguagem']} | {i['finalidade']} | `{i['sha256'][:12]}` |\n")
    print(f"Manifesto gerado: {len(itens)} arquivos")
    return 0


if __name__ == "__main__":
    sys.exit(main())
