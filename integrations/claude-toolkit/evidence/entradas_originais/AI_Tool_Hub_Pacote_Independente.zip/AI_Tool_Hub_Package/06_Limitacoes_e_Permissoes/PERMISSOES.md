# 06 — Permissões, rede e dados

## Navegador (JavaScript)

| Item | Uso |
|---|---|
| Rede | Nenhuma. As páginas de demonstração têm uma política de segurança (`connect-src 'none'`) que bloqueia requisições de rede. |
| Armazenamento (localStorage, cookies, IndexedDB) | Não usado. Ao fechar a página, nada fica salvo. |
| Câmera, microfone, localização, notificações, vibração, áudio | Não usados; nenhuma permissão é solicitada. |
| Bibliotecas externas, fontes, CDNs | Nenhuma. Todo o código está nos arquivos do pacote. |
| `innerHTML` | Usado em um único ponto (inserir o SVG gerado pela ferramenta de gráfico), cuja saída é escapada e testada. O restante usa `textContent`. |

## Python

| Item | Uso |
|---|---|
| Rede | Nenhuma. |
| Arquivos | A linha de comando (`python -m ai_tool_hub`) lê somente os JSONs cujo caminho você informa. As funções da biblioteca não acessam arquivos. |
| Dependências | Nenhuma além da biblioteca padrão. |

## Dados e segredos

O pacote não contém credenciais, tokens, chaves de API, dados pessoais nem dados de usuários. Os exemplos usam dados fictícios e o domínio reservado `example.com`.
