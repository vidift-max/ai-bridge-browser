# 06 — Limitações e funcionalidades não implementadas

## 1. O que este pacote é e o que não é

- **É:** cinco ferramentas pequenas, escritas do zero para este pacote, em JavaScript e em Python, com testes.
- **Não é:** uma exportação, cópia ou reconstrução de qualquer ferramenta interna do Claude. Nenhum código, instrução, esquema ou componente interno da Anthropic foi incluído. As ferramentas daqui têm finalidades parecidas com algumas funções comuns de assistentes (cronômetro, receita, quiz, gráfico, cartão de link), mas **não reproduzem o comportamento nem a interface de nenhuma ferramenta da plataforma**.
- **Não é** uma integração: nada foi conectado ao AI Bridge Browser nem ao AI Tool Hub, e nenhuma simulação é apresentada como integração real.

## 2. Ferramentas da plataforma que NÃO foram exportadas, e por quê

| Ferramenta / capacidade | Motivo |
|---|---|
| Execução de código, edição de arquivos, ambiente de arquivos | É o ambiente de execução da plataforma, não um artefato distribuível. |
| Busca na web, leitura de páginas, busca de imagens | Serviços hospedados e de terceiros; dependem de acesso e licenças que não pertencem a este pacote. |
| Agenda, alarmes, timers do aparelho, localização, clima, lugares e mapas, esportes, resultados de eleições | Dependem do aplicativo do celular, de permissões do sistema ou de fontes de dados de terceiros. Não há código a redistribuir. |
| Memória persistente | Armazena dados privados de usuários; não pode ser exportada. |
| Conectores externos (MCP) e documentos do Claude | Dependem de contas e autorizações de terceiros. |
| Instruções internas e arquivos de "skills" | Material interno da plataforma; não redistribuível. |
| Cartões de interface do chat (quiz, receita, gráfico, tradução, rascunho de mensagem, cartões de links) | O código original é interno. Só foram escritas **ferramentas novas e independentes** com finalidades semelhantes, listadas na seção 3. |
| Tradução e rascunho de mensagens | Exigem um modelo de linguagem; não há como entregar uma versão local e gratuita sem simular o resultado. Não foram implementadas para não passar uma simulação por ferramenta real. |

## 3. Funcionalidades sugeridas e ainda NÃO implementadas

- Alertas do cronômetro (som, vibração, notificação): exigiriam permissões que o pacote evita de propósito.
- Frações visuais (½, ¼) e unidades em português; densidades para converter volume em massa; xícara métrica.
- Quiz: embaralhar opções, múltiplas respostas corretas, tempo limite, geração automática de perguntas.
- Gráfico: valores negativos, mais de 6 séries, pizza, eixos com título, legendas interativas, exportar PNG.
- Cartão de link: busca de título e imagem (exige rede), conversão de domínios internacionais no Python.
- Salvar dados entre sessões.
- Tradução e rascunho de mensagens (ver seção 2).
- Empacotamento para publicação (PyPI, npm) e licença de código aberto.

## 4. Limites da verificação

- **Nenhum teste foi feito em navegador real nem em aparelho Android.** Foram executados: testes em Node.js (v22), testes em Python (3.12), um teste de paridade JS × Python, e uma simulação do carregamento "como navegador" com um DOM falso. Veja `05_Testes/RELATORIO_TESTES.md`.
- A página `smoke_test.html` foi escrita para você rodar no navegador do Android, mas **ainda não foi executada em um navegador real**.
- Python 3.9–3.11 e Node.js anteriores à v22 não foram testados (o `pyproject.toml` declara 3.9 por usar apenas recursos antigos da linguagem, mas isso não foi comprovado).
- Não houve auditoria de acessibilidade, desempenho, nem revisão de segurança independente.
- **Nenhuma licença foi definida** para o código. Defina uma antes de redistribuir ou integrar.
- Não há screenshots (ver `02_Documentacao_Visual/README.md`).

## 5. Diferenças conhecidas entre JavaScript e Python

- Resultados numéricos inteiros aparecem como `5400` em JS e `5400.0` em Python em alguns casos; os valores são iguais.
- URLs com domínios internacionais: o JavaScript converte para punycode, o Python mantém o texto original.
- Os testes de paridade cobrem 28 casos; não provam equivalência total.
