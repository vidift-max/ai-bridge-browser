# 03 — Contratos das ferramentas (API)

Este documento descreve entradas, saídas, erros, permissões e limitações das cinco ferramentas. Os nomes em JavaScript usam camelCase e os de Python usam snake_case. O comportamento é o mesmo nas duas linguagens (verificado por `05_Testes/paridade_js_python.py`).

**Importante:** isto é a API do pacote independente. Não é a API de nenhuma ferramenta interna do Claude e não há integração com o AI Bridge Browser.

## Erros (comum a todas)

Toda falha lança `ToolError` (JS: `error.name === 'ToolError'`; Python: `ai_tool_hub.ToolError`) com o atributo `code` (texto estável) e `message` (texto em português para pessoas).

## Permissões (comum a todas)

Nenhuma. As ferramentas não usam rede, localStorage, cookies, câmera, microfone, localização, notificações, som nem vibração. A única leitura de arquivos acontece na linha de comando Python, e apenas nos caminhos informados.

---

## 1. duration_timer — `01_Ferramentas_Exportaveis/js/tools/duration_timer.js` e `python/ai_tool_hub/duration_timer.py`

**Finalidade:** interpretar durações, formatá-las e controlar um cronômetro regressivo.

| Função (JS / Python) | Entrada | Saída |
|---|---|---|
| `parseDuration(x)` / `parse_duration(x)` | texto (`"90"`, `"5m"`, `"1h30m"`, `"2m 30s"`, `"1:30"`, `"1:02:03"`, `"1d"`) ou número de segundos | segundos (número, até 3 casas) |
| `formatDuration(s, estilo)` / `format_duration(s, estilo)` | segundos ≥ 0; estilo `"clock"` (padrão, `01:02:03`) ou `"words"` (`1h 2m 3s`) | texto |
| `createTimer(s, relogio)` / `Timer(s, clock)` | segundos > 0; relógio opcional (ms em JS, segundos em Python) | objeto com `start`, `pause`, `resume`, `reset`, `remaining`, `state` |

Estados: `idle` → `running` ⇄ `paused` → `finished`.

**Códigos de erro:** `EMPTY_INPUT`, `INVALID_FORMAT`, `OUT_OF_RANGE` (acima de 7 dias ou cronômetro com 0 s), `INVALID_STATE` (ex.: pausar um cronômetro parado).

**Limitações:** sem som, vibração ou notificação ao terminar; em segundo plano, navegadores móveis podem pausar os temporizadores da página (a contagem usa o relógio, então o tempo restante continua correto ao voltar); máximo de 7 dias; unidades `d`, `h`, `m`, `s` (sem semanas ou meses).

## 2. recipe_scaler — `recipe_scaler.js` / `recipe_scaler.py`

**Finalidade:** escalar receitas por porções e converter unidades.

| Função | Entrada | Saída |
|---|---|---|
| `convert(qtd, de, para)` | número ≥ 0 e duas unidades | número (6 casas) |
| `scaleRecipe(receita, porcoes)` / `scale_recipe` | `{title?, base_servings, ingredients:[{name, amount, unit}]}` e porções > 0 | `{title, base_servings, scale_factor, ingredients}` (a entrada não é alterada) |
| `formatAmount(v)` / `format_amount` | número | texto com até 2 casas, sem zeros à direita |

Unidades: `ml, l, tsp, tbsp, fl_oz, cup` (volume, padrão americano) e `g, kg, oz, lb` (massa). Apelidos: `teaspoon, tablespoon, fl oz, cups, milliliter, liter, gram, kilogram, ounce, pound`. `unit` pode ser `null` (itens contáveis).

**Códigos de erro:** `UNKNOWN_UNIT`, `INCOMPATIBLE_UNITS`, `INVALID_AMOUNT`, `INVALID_RECIPE`, `INVALID_SERVINGS`.

**Limitações:** não converte volume em massa (não há densidades); `cup`, `tsp` e `tbsp` seguem o padrão americano (a xícara métrica de 250 ml não é usada); não formata frações (`½`); só unidades em inglês abreviado.

## 3. quiz_engine — `quiz_engine.js` / `quiz_engine.py`

**Finalidade:** validar e corrigir quizzes de múltipla escolha.

| Função | Entrada | Saída |
|---|---|---|
| `validateQuiz(quiz)` / `validate_quiz` | `{title, questions:[{id, prompt, options:[{id,text}], correct_option_id, explanation?}]}` | `{valid, errors[]}` (não lança erro) |
| `grade(quiz, respostas)` | o quiz e `{idPergunta: idOpção}` | `{title, total, correct, score_percent, results[], unknown_answer_ids[]}` |

Cada item de `results`: `id, answered, selected, selected_valid, is_correct, correct_option_id, explanation`.

**Códigos de erro:** `INVALID_QUIZ` (a mensagem lista os problemas), `INVALID_ANSWERS`.

**Limitações:** uma única resposta correta por pergunta; não embaralha opções; não gera perguntas; sem tempo limite, sem pontuação ponderada; nada é salvo.

## 4. svg_chart — `svg_chart.js` / `svg_chart.py`

**Finalidade:** gerar gráficos de barras ou linhas como texto SVG.

| Função | Entrada | Saída |
|---|---|---|
| `renderChart(spec)` / `render_chart` | `{type:"bar"\|"line", title?, labels[1..50], series[1..6]:[{name?, values[]}], width?(200–2000, padrão 640), height?(150–2000, padrão 360)}` | texto SVG |

**Códigos de erro:** `INVALID_SPEC`, `LENGTH_MISMATCH`, `INVALID_VALUE`, `NEGATIVE_VALUE`, `INVALID_SIZE`.

**Segurança:** título, rótulos e nomes de série são escapados (XML) e limpos de caracteres de controle. Mesmo assim, ao inserir o SVG numa página, trate-o como conteúdo gerado: a demonstração o insere com `innerHTML`, o que é adequado porque a saída é escapada e coberta por testes.

**Limitações:** só valores ≥ 0; só barras agrupadas e linhas; sem eixos com título, sem rótulos de valores, sem animação, sem interação; paleta fixa de 6 cores (não validada para daltonismo); rótulos truncados em 20 caracteres.

## 5. link_card — `link_card.js` / `link_card.py`

**Finalidade:** validar uma URL e montar um cartão de link seguro.

| Função | Entrada | Saída |
|---|---|---|
| `buildLinkCard({url, title?, description?})` / `build_link_card` | URL `http`/`https`; título (até 120) e descrição (até 300) opcionais | `{url (normalizada), host, title, description, html}` |

O `html` gerado tem texto escapado e `rel="noopener noreferrer nofollow"`.

**Códigos de erro:** `EMPTY_INPUT`, `INVALID_URL`, `UNSUPPORTED_SCHEME` (`javascript:`, `data:`, `file:` etc.), `CREDENTIALS_IN_URL`.

**Limitações:** **não acessa a internet** — não obtém o título, a imagem ou a descrição da página; não verifica se o site existe nem se é seguro; domínios internacionais (IDN) não são convertidos para punycode no Python; URLs de até 2048 caracteres.

---

## Integração

Nada foi integrado a nenhum sistema. Para avaliação, cada ferramenta é um módulo isolado, sem estado global e sem dependências, que pode ser carregado por `<script>` (JS, objeto global `AIToolHub`), `require` (Node.js) ou `import` (Python).
