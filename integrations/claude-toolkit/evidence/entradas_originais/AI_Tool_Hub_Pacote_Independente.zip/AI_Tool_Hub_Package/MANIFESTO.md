# Manifesto de arquivos

Categorias: `implementacao_original` (ferramenta escrita para este pacote), `interface_demo`, `script_auxiliar`, `configuracao`, `documentacao`, `exemplo` (não é ferramenta), `saida_de_exemplo`, `teste`, `relatorio`. SHA-256 completo em `MANIFESTO.json`. O próprio manifesto não tem hash listado.

| Arquivo | Ferramenta | Categoria | Linguagem | Finalidade | SHA-256 (início) |
|---|---|---|---|---|---|
| `01_Ferramentas_Exportaveis/js/app.js` | (todas) | interface_demo | JavaScript | Liga a interface de demonstração às ferramentas | `fcaaec32a971` |
| `01_Ferramentas_Exportaveis/js/build_standalone.py` | - | script_auxiliar | Python | Gera as versões de arquivo único das páginas | `5b65023b3a27` |
| `01_Ferramentas_Exportaveis/js/index.html` | (todas) | interface_demo | HTML/CSS | Página de demonstração (carrega tools/*.js) | `8ec8ad156d66` |
| `01_Ferramentas_Exportaveis/js/index.js` | (todas) | script_auxiliar | JavaScript | Ponto de entrada para Node.js (require) | `4d91d37e9e54` |
| `01_Ferramentas_Exportaveis/js/index_standalone.html` | (todas) | interface_demo | HTML/CSS/JS | Demonstração em arquivo único (gerado por build_standalone.py) | `1ce1976f94cb` |
| `01_Ferramentas_Exportaveis/js/smoke_test.html` | (todas) | teste | HTML/JS | Teste rápido para rodar no navegador (carrega tools/*.js) | `0032f4d24cc6` |
| `01_Ferramentas_Exportaveis/js/smoke_test_standalone.html` | (todas) | teste | HTML/JS | Teste rápido em arquivo único, indicado para Android | `ab06d98e83f3` |
| `01_Ferramentas_Exportaveis/js/tools/core.js` | (apoio) | implementacao_original | JavaScript | Erro comum (ToolError) e utilitários de escape/limpeza de texto | `0e22b567583f` |
| `01_Ferramentas_Exportaveis/js/tools/duration_timer.js` | duration_timer | implementacao_original | JavaScript | Interpretar/formatar durações e cronômetro regressivo | `994de69edad0` |
| `01_Ferramentas_Exportaveis/js/tools/link_card.js` | link_card | implementacao_original | JavaScript | Validar URL e montar cartão de link | `384bc73f6081` |
| `01_Ferramentas_Exportaveis/js/tools/quiz_engine.js` | quiz_engine | implementacao_original | JavaScript | Validar e corrigir quizzes | `17c78b0f3b12` |
| `01_Ferramentas_Exportaveis/js/tools/recipe_scaler.js` | recipe_scaler | implementacao_original | JavaScript | Escalar receitas e converter unidades | `07b11be58bf6` |
| `01_Ferramentas_Exportaveis/js/tools/svg_chart.js` | svg_chart | implementacao_original | JavaScript | Gerar gráficos SVG de barras e linhas | `b90428096694` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/__init__.py` | (apoio) | implementacao_original | Python | Exporta as ferramentas do pacote | `a09bec9c78c3` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/__main__.py` | (todas) | implementacao_original | Python | Linha de comando: python -m ai_tool_hub | `19093423f554` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/duration_timer.py` | duration_timer | implementacao_original | Python | Interpretar/formatar durações e cronômetro regressivo | `69eccc7233ec` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/errors.py` | (apoio) | implementacao_original | Python | Erro comum (ToolError) e utilitários | `a522ff51d2cc` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/link_card.py` | link_card | implementacao_original | Python | Validar URL e montar cartão de link | `e132517de9d2` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/quiz_engine.py` | quiz_engine | implementacao_original | Python | Validar e corrigir quizzes | `71b49e318cae` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/recipe_scaler.py` | recipe_scaler | implementacao_original | Python | Escalar receitas e converter unidades | `20e6206aa2fc` |
| `01_Ferramentas_Exportaveis/python/ai_tool_hub/svg_chart.py` | svg_chart | implementacao_original | Python | Gerar gráficos SVG de barras e linhas | `48e15d60d72e` |
| `01_Ferramentas_Exportaveis/python/pyproject.toml` | - | configuracao | TOML | Metadados para instalar com pip (sem dependências) | `5d3a4d3779f1` |
| `01_Ferramentas_Exportaveis/python/requirements-dev.txt` | - | configuracao | Texto | Dependência opcional de desenvolvimento (pytest) | `69d507e0c35e` |
| `01_Ferramentas_Exportaveis/python/requirements.txt` | - | configuracao | Texto | Dependências de execução (nenhuma) | `f9d1239eb397` |
| `02_Documentacao_Visual/README.md` | - | documentacao | Markdown | Por que não há screenshots e roteiro para capturá-los | `a43b474b3869` |
| `03_APIs_e_Integracoes/API.md` | (todas) | documentacao | Markdown | Entradas, saídas, erros, permissões e limitações | `b580ac2e864c` |
| `04_Exemplos_de_Uso/exemplo_js.js` | (todas) | exemplo | JavaScript | Exemplo de uso em Node.js | `1b75625c3129` |
| `04_Exemplos_de_Uso/exemplo_python.py` | (todas) | exemplo | Python | Exemplo de uso em Python | `77e02289a718` |
| `04_Exemplos_de_Uso/grafico.json` | svg_chart | exemplo | JSON | Especificação de gráfico de exemplo | `1323ac3285d7` |
| `04_Exemplos_de_Uso/quiz.json` | quiz_engine | exemplo | JSON | Quiz fictício de exemplo | `b282bd929bc4` |
| `04_Exemplos_de_Uso/receita.json` | recipe_scaler | exemplo | JSON | Receita fictícia de exemplo | `5dfcad982b46` |
| `04_Exemplos_de_Uso/respostas.json` | quiz_engine | exemplo | JSON | Respostas de exemplo | `2e3a6544c59c` |
| `04_Exemplos_de_Uso/saida_grafico_js.svg` | svg_chart | saida_de_exemplo | SVG | Saída gerada pela versão JS ao rodar o exemplo | `e33a2445bded` |
| `04_Exemplos_de_Uso/saida_grafico_py.svg` | svg_chart | saida_de_exemplo | SVG | Saída gerada pela versão Python ao rodar o exemplo | `e33a2445bded` |
| `05_Testes/RELATORIO_TESTES.md` | (todas) | relatorio | Markdown | Resultado real da última execução dos testes | `fc6141a255f1` |
| `05_Testes/executar_todos.py` | (todas) | teste | Python | Executa todos os testes e grava o relatório | `76f74df3c9c5` |
| `05_Testes/gerar_manifesto.py` | - | script_auxiliar | Python | Gera este manifesto | `0c418961c253` |
| `05_Testes/js/duration_timer.test.js` | duration_timer | teste | JavaScript | Testes automatizados (node:test) | `7790f65784ee` |
| `05_Testes/js/link_card.test.js` | link_card | teste | JavaScript | Testes automatizados (node:test) | `3228e640aa81` |
| `05_Testes/js/quiz_engine.test.js` | quiz_engine | teste | JavaScript | Testes automatizados (node:test) | `b75f1086eee2` |
| `05_Testes/js/recipe_scaler.test.js` | recipe_scaler | teste | JavaScript | Testes automatizados (node:test) | `0bd021ee953c` |
| `05_Testes/js/svg_chart.test.js` | svg_chart | teste | JavaScript | Testes automatizados (node:test) | `0d4dd061e11d` |
| `05_Testes/paridade_js_python.py` | (todas) | teste | Python | Compara as respostas das versões JS e Python | `d95ac083c449` |
| `05_Testes/python/_helpers.py` | (apoio) | teste | Python | Auxiliar dos testes Python | `9d2db519ab2c` |
| `05_Testes/python/test_cli.py` | (todas) | teste | Python | Testes da linha de comando | `e6dc69e9b377` |
| `05_Testes/python/test_duration_timer.py` | duration_timer | teste | Python | Testes automatizados (unittest) | `db949b1eff0d` |
| `05_Testes/python/test_link_card.py` | link_card | teste | Python | Testes automatizados (unittest) | `f64aeeb99d62` |
| `05_Testes/python/test_quiz_engine.py` | quiz_engine | teste | Python | Testes automatizados (unittest) | `05117fe12144` |
| `05_Testes/python/test_recipe_scaler.py` | recipe_scaler | teste | Python | Testes automatizados (unittest) | `1a62441c9bfd` |
| `05_Testes/python/test_svg_chart.py` | svg_chart | teste | Python | Testes automatizados (unittest) | `b7caf4a6844e` |
| `05_Testes/simulacao_navegador.js` | (todas) | teste | JavaScript | Simula o carregamento no navegador com DOM falso | `ba728511d42b` |
| `06_Limitacoes_e_Permissoes/LIMITACOES.md` | - | documentacao | Markdown | O que não foi exportado, o que falta e limites da verificação | `c86a4e4d9b51` |
| `06_Limitacoes_e_Permissoes/PERMISSOES.md` | - | documentacao | Markdown | Permissões, rede, armazenamento e dados | `2f713457bf3a` |
| `README.md` | - | documentacao | Markdown | Visão geral, instruções para computador e Android | `9613544c73b5` |
