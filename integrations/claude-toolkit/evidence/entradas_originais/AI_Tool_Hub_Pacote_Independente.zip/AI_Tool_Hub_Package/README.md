# AI Tool Hub — pacote independente para auditoria

Pacote com **cinco ferramentas locais e gratuitas**, escritas do zero em **JavaScript** (navegador, sem servidor) e **Python** (sem dependências), com testes automatizados e documentação. Foi preparado para avaliação de uma possível integração ao AI Tool Hub do AI Bridge Browser.

> **Não há nenhuma integração.** Nada aqui se conecta ao AI Bridge Browser, ao AI Tool Hub ou a qualquer serviço. Também **não há código, instruções ou componentes internos da Anthropic**: as ferramentas são implementações originais e independentes. O que não pôde ser exportado, e por quê, está em `06_Limitacoes_e_Permissoes/LIMITACOES.md`.

## Ferramentas (todas "implementação original independente")

| Ferramenta | Finalidade | JavaScript | Python |
|---|---|---|---|
| `duration_timer` | Interpretar durações (`1h30m`, `1:30`) e cronômetro regressivo | `js/tools/duration_timer.js` | `ai_tool_hub/duration_timer.py` |
| `recipe_scaler` | Escalar receitas e converter unidades de cozinha | `js/tools/recipe_scaler.js` | `ai_tool_hub/recipe_scaler.py` |
| `quiz_engine` | Validar e corrigir quizzes de múltipla escolha | `js/tools/quiz_engine.js` | `ai_tool_hub/quiz_engine.py` |
| `svg_chart` | Gráficos de barras e linhas em SVG | `js/tools/svg_chart.js` | `ai_tool_hub/svg_chart.py` |
| `link_card` | Validar URL e montar cartão de link seguro (sem acessar a internet) | `js/tools/link_card.js` | `ai_tool_hub/link_card.py` |

**O que é ferramenta e o que é só exemplo:**
- **Ferramentas:** `01_Ferramentas_Exportaveis/` (as cinco acima, mais `core.js`/`errors.py` de apoio).
- **Interface de demonstração (não é ferramenta):** `index.html`, `index_standalone.html`, `app.js`.
- **Exemplos (não são ferramentas):** tudo em `04_Exemplos_de_Uso/`.
- **Testes:** `05_Testes/`. A lista completa, com linguagem e finalidade de cada arquivo, está em `MANIFESTO.md` (e `MANIFESTO.json`, com SHA-256).

## Estrutura

```
01_Ferramentas_Exportaveis/   js/ (ferramentas + demo)  python/ (pacote ai_tool_hub)
02_Documentacao_Visual/       sem screenshots (explicação e roteiro de captura)
03_APIs_e_Integracoes/        API.md: entradas, saídas, erros, permissões, limitações
04_Exemplos_de_Uso/           exemplos em JS e Python com dados fictícios
05_Testes/                    testes JS e Python, paridade, simulação, RELATORIO_TESTES.md
06_Limitacoes_e_Permissoes/   LIMITACOES.md, PERMISSOES.md
MANIFESTO.md / MANIFESTO.json
```

## Executar no computador (Windows, macOS, Linux)

Requisitos: Python 3.9+ (testado só na 3.12) e, opcionalmente, Node.js (testado só na v22) para os testes de JavaScript.

**Interface no navegador (sem servidor):** descompacte o ZIP e dê dois cliques em `01_Ferramentas_Exportaveis/js/index.html`. Se preferir um arquivo só, use `index_standalone.html`.

**Python (instalação e execução):**
```
cd 01_Ferramentas_Exportaveis/python
python3 -m ai_tool_hub parse-duration 1h30m
python3 -m ai_tool_hub convert 1 cup ml
python3 -m ai_tool_hub scale ../../04_Exemplos_de_Uso/receita.json 6
python3 -m ai_tool_hub chart ../../04_Exemplos_de_Uso/grafico.json > grafico.svg
python3 -m ai_tool_hub link-card https://example.com --titulo "Exemplo"
```
Instalação opcional como pacote: `pip install .` dentro de `01_Ferramentas_Exportaveis/python` (não há dependências; `requirements.txt` só registra isso). No Windows, use `python` no lugar de `python3`.

**Node.js (uso em scripts):** `const hub = require('./01_Ferramentas_Exportaveis/js/index.js');`

**Exemplos:** `python3 04_Exemplos_de_Uso/exemplo_python.py` e `node 04_Exemplos_de_Uso/exemplo_js.js`.

**Testes (tudo de uma vez):**
```
python3 05_Testes/executar_todos.py
```
Ou separados: `node --test 05_Testes/js/*.test.js` e, em `05_Testes/python`, `python3 -m unittest discover -v`. Se o Node.js não estiver instalado, as etapas de JavaScript aparecem como PULADAS.

## Executar no Android

Estas instruções **não foram testadas em um aparelho Android**.

**A) Navegador, sem servidor e sem instalar nada**
1. Copie o ZIP para o celular e extraia no app **Arquivos** (toque no ZIP e escolha Extrair).
2. Abra `01_Ferramentas_Exportaveis/js/index_standalone.html` com o **Chrome** (toque no arquivo e escolha Abrir com Chrome). Use as versões `*_standalone.html`: elas têm todo o código dentro do próprio arquivo, o que evita falhas de carregamento de arquivos vizinhos quando o Android abre o arquivo por um endereço `content://`.
3. Teste rápido: abra `smoke_test_standalone.html`. A página deve mostrar "13 de 13 verificações passaram."
4. Se aparecer "FALHA" ou o contador não aparecer, anote o texto exibido; isso é exatamente o que precisamos saber.

**B) Python e Node.js no celular (Termux, opcional)**
1. Instale o Termux e, nele: `pkg install python nodejs unzip`.
2. `cd` até a pasta extraída (ex.: `cd ~/storage/downloads/AI_Tool_Hub_Package`; rode `termux-setup-storage` antes se for a primeira vez).
3. `python 05_Testes/executar_todos.py`

## Segurança e privacidade em resumo

Sem rede, sem armazenamento, sem permissões, sem chaves, sem dados pessoais. Detalhes em `06_Limitacoes_e_Permissoes/PERMISSOES.md`.

## Resultados dos testes

Veja `05_Testes/RELATORIO_TESTES.md` (resultado de uma execução real, com o que **não** foi testado). **Nenhum teste foi feito em navegador real nem em Android.**
