# Matriz de evidências e resultados históricos

**Atenção:** os números abaixo são transcrições de registros históricos recuperados. Não foram reexecutados nesta sessão.

## Testes históricos encontrados nos registros
| Área | Resultado histórico | Observação |
|---|---:|---|
| Python unit tests | 26/26 PASS | Registro de `python3 -m unittest discover -v`; versão histórica. |
| Python unit tests | 68/68 PASS | Informado anteriormente pelo usuário como resultado histórico; não localizado no repositório durante a auditoria read-only. |
| JavaScript tests | 27/27 PASS | Resultado histórico reportado na conversa, precisa localizar o log primário. |
| Python/JavaScript parity | 27/28 PASS | Registro histórico com divergência IPv6 em `link_card`. |
| Python/JavaScript parity | 28/28 PASS | Resultado posterior informado no histórico; confirmar qual revisão corrigiu o caso e localizar evidência primária. |
| Browser simulation | 5/5 PASS | Resultado histórico reportado; não é prova de Chrome/Android real. |
| Compliance scenarios | 94 cenários | Informado pelo usuário; não localizados no repositório durante a auditoria. |
| SVG security | 65 casos | Planejado/solicitado como validação; execução atual não comprovada. |

## Divergência Python/JavaScript registrada
Caso: `linkCard.buildLinkCard([{"url":"http://[::1]:8080/x"}]...)`.

- JavaScript preservava o host/título como `[::1]`.
- Python removia os colchetes e apresentava `::1`.
- O registro histórico marcou paridade 27/28.
- Uma alegação posterior de 28/28 existe, mas sem artefato primário recuperado nesta auditoria. A nova conta deve localizar o commit/log que corrigiu o caso e reexecutar o teste em ambas as linguagens.

## Estado do pacote ZIP no GitHub
- Caminho: `integrations/AI_Tool_Hub_Pacote_Independente.zip`
- Git blob SHA: `7bb74b7b4033a5384aaff4ed05bd8473a180dc22`
- Esse valor é o SHA do blob Git, **não** o SHA-256 dos bytes do ZIP.
- O conteúdo retornado pela API veio em Base64 (`UEsDB...`), compatível com ZIP binário.
- Inspeção estrutural preliminar manual indicou 56 entradas; não foi concluída extração real, verificação de CRC nem cálculo confiável de SHA-256 do ZIP.
- Tamanho histórico informado: 94.977 bytes. Não usar como checksum.

## Evidências não localizadas ou não verificadas
- Python 68/68 e os 94 cenários não foram encontrados nos arquivos pesquisados do repositório.
- Não foi localizado contrato técnico completo com hash verificável, autenticação, schemas e permissões.
- Não foi localizada licença/titularidade explícita do pacote.
- Não foram executados novos testes por GPT-6 nesta sessão.
- Não houve extração completa do ZIP, build, teste de browser, teste Android, commit ou push nesta auditoria.

## Estado do repositório observado em 2026-11-28
- Repo público `vidift-max/ai-bridge-browser`.
- Branch `v2-saas-alpha`.
- HEAD observado: `5636e8253dada908da5c2830527ba78795e90c0b`.
- Arquivo `docs/AI_TOOL_BRIDGE.md` (blob `8ea000f51981b7f45ae34a4be37adee0417f8809`) contém apenas princípios gerais:
  - provider deve expor interface autorizada;
  - bridge deve expor discovery, auth, contracts, schemas, permission scope e errors/rate limits;
  - chamadas não documentadas/não autorizadas devem ser rejeitadas.
- `integrations/README.md` lista Kimi, Claude, Gemini e provider genérico como adapters planejados e proíbe commitar credenciais.
- A árvore da branch tinha o ZIP e docs, mas não continha fontes do AI Tool Hub extraídas em diretórios de adapters/bridge/schemas/auth.

## Segurança e licença
- Autenticação não pode confiar em `caller`/`principal` fornecido pelo cliente sem verificação criptográfica ou sessão validada no servidor.
- Identidade efetiva deve vir da credencial verificada pelo servidor.
- Não assumir que licença permissiva existe. Não distribuir/publicar como pacote integrado até identificar autor, licença e autorização.
