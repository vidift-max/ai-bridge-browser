# AI Tool Hub — pacote de transferência para outra conta Claude

**Tipo:** pacote de continuidade documental (handoff)  
**Data:** 2026-11-28  
**Estado:** PARCIAL — não contém o workspace original nem o código-fonte extraído do ZIP.

## Objetivo
Permitir que outra conta Claude continue o trabalho do AI Tool Hub sem perder o contexto, sem repetir trabalho já comprovado e sem transformar resultados históricos em testes atuais.

## Conteúdo
- `01_CONTEXT/ESTADO_DO_PROJETO.md`: contexto, escopo e regras.
- `02_EVIDENCE/MATRIZ_DE_EVIDENCIAS.md`: resultados históricos conhecidos, divergências e bloqueios.
- `02_EVIDENCE/INVENTARIO_GITHUB.md`: estado observado do repositório.
- `03_NEXT_MISSION/PROMPT_PARA_CLAUDE.md`: instrução pronta para a nova conta.
- `MANIFEST_SHA256.txt`: hashes SHA-256 dos arquivos deste pacote.

## Limitação importante
Este ZIP **não inclui** `/home/claude/work/pkg`, o código-fonte extraído, nem o binário original `AI_Tool_Hub_Pacote_Independente.zip`. O conteúdo disponível nesta sessão permite transferir contexto e evidências, mas não reconstruir com segurança o projeto-fonte. A nova conta deve solicitar os arquivos originais quando necessário e continuar, enquanto isso, apenas as tarefas read-only e documentais possíveis.

## Segurança
Não inclua chaves de API, tokens, cookies, senhas, credenciais OAuth ou dados privados no pacote. Não autorize deploy, merge, release ou alteração de produção.
