# PROMPT DE CONTINUIDADE — AI TOOL HUB (NOVA CONTA CLAUDE)

Você está recebendo um pacote de transferência documental. Leia todos os arquivos antes de agir.

## Missão
Assumir a continuidade do AI Tool Hub exatamente do estado documentado, sem descartar o trabalho da conta Claude anterior e sem repetir etapas já comprovadas sem necessidade.

## Primeira etapa obrigatória — preservação
1. Confirme se você realmente tem acesso ao workspace `/home/claude/work/pkg`. Não alegue acesso se não tiver.
2. Se tiver acesso: registre `pwd`, `git status --short --branch`, `git log -10 --oneline --decorate`, HEAD, branch e inventário completo dos arquivos. Faça backup antes de qualquer edição.
3. Se não tiver acesso: não reconstrua código por suposição. Peça o ZIP completo do workspace e preserve o trabalho documental/read-only que puder ser feito.
4. Não sobrescreva, remova ou limpe alterações preexistentes.

## Escopo técnico
Auditar e completar:
- `duration_timer`
- `recipe_scaler`
- `quiz_engine`
- `svg_chart`
- `link_card`
- adapters Python e JavaScript
- manifests e schemas
- capability discovery e contratos de invocação
- autenticação confiável (não aceitar `caller` fornecido livremente)
- permissões, limites, rate limits, erros e logs sem segredos
- validação de SVG/DOM e entradas malformadas
- hash SHA-256 do contrato comparado aos bytes reais
- licença/titularidade/autorização de uso

## Testes
Localize os logs primários dos números históricos. Não os trate como resultados atuais.
Execute os testes possíveis no código real:
- Python unit tests
- JavaScript unit tests
- 94 cenários de conformidade (ou conjunto atualizado equivalente)
- 65 casos SVG (ou conjunto atualizado equivalente)
- paridade Python/JavaScript, incluindo IPv6 `[::1]`
- spoofing de identidade e autenticação
- permissões e rate limits
- regressão, sintaxe e imports
- inputs malformados e segurança
- UI/smoke apenas no ambiente realmente disponível

Registre comandos, versões, exit codes, logs e hashes. Diferencie PASS, FAIL, BLOCKED e NOT RUN. Não alegue Chrome ou Android real sem executar nesses ambientes.

## GitHub
Repo `vidift-max/ai-bridge-browser`, branch `v2-saas-alpha`.
A instrução anterior do usuário permite commits e push somente depois de auditoria e verificação do conteúdo, sem merge/release/deploy. Antes de publicar, confirme que a autorização continua aplicável e registre SHA, diff, testes e artefatos.
Não faça merge, release, deploy, reset, force-push, alteração de secrets ou configuração de produção.

## Custo e operação
Preferir execução local-first e custo obrigatório US$0/mês. Não provisionar Render pago.

## Entrega final
- fontes completas e verificadas;
- `AI_Tool_Hub_Bridge_Integrado.zip`;
- manifesto SHA-256 calculado sobre os bytes finais;
- testes e logs;
- inventário de licenças/autorização;
- branch, commit e SHA, se houver publicação autorizada;
- tabela PASS/FAIL/BLOCKED/NOT RUN;
- pendências reais.

Não declarar concluído se identidade não for confiável, houver divergência Python/JS, falha crítica ou licença não esclarecida.
