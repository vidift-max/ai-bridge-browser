# Estado do AI Tool Hub

## Projeto
- Repositório: `vidift-max/ai-bridge-browser`
- Branch alvo: `v2-saas-alpha`
- Diretório local histórico do Claude: `/home/claude/work/pkg` (não acessível nesta sessão)
- Objetivo: completar cinco ferramentas (`duration_timer`, `recipe_scaler`, `quiz_engine`, `svg_chart`, `link_card`), adapters Python/JavaScript, manifests, schemas, discovery, invocação autorizada, permissões, validação, limites, erros e logs sem segredos.

## Escopo e restrições
- Preservar arquivos e alterações preexistentes; começar por `git status`, `git log`, HEAD e inventário.
- Não confiar em `caller` livre fornecido pelo solicitante. Identidade deve ser derivada de autenticação validada.
- Conferir SHA-256 do contrato `AI_TOOL_BRIDGE.md` contra os bytes reais.
- Validar schemas, manifests, permissões, limites, SVG e DOM.
- Não inventar licença, titularidade ou autorização de uso.
- Não fazer merge, release, deploy, secrets, configuração de produção, reset ou force-push.
- A autorização anterior do usuário permitia commits e push na branch `v2-saas-alpha` somente após auditoria e verificação do conteúdo, sem merge/release/deploy. Essa autorização não substitui a necessidade de ter os arquivos reais e verificar cada alteração.
- O objetivo de produto do usuário é local-first e US$0/mês; não provisionar Render pago.

## Separação obrigatória
Registrar separadamente:
1. implementação encontrada;
2. testes históricos registrados por terceiros;
3. testes executados agora pela nova conta;
4. integração com o AI Bridge Browser;
5. build Android;
6. deployment/runtime real.

## Condição de conclusão
Não declarar concluído enquanto houver falha crítica, identidade não confiável, divergência Python/JavaScript ou licença/titularidade sem esclarecimento.
